"""Single bounded exact-kernel optimization qualification, no potential fit."""
import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS']:os.environ[k]='1'
from pathlib import Path
import json,hashlib,sys
import numpy as np
H=Path(__file__).resolve().parent;B=H.parent;sys.path.insert(0,str(B/'round6_engine'));from native import create
M=H/'optimized_alias.json';source=B/'round6_fit/N512_q34_s0/trajectory.npz';plugin=H/'fast_kernel/cg_joint_fast.dylib';z=np.load(source);pos=z['positions_A'];cells=z['cell_A'];rows=[]
def instance(x,b,prefix,fast):
 l=create(M,x,b,prefix)
 if fast:l.commands_list([f'plugin load {plugin}','pair_style cg/joint/fast',f'pair_coeff * * {Path(prefix).with_suffix(".params")}'])
 return l
for i in np.unique(np.linspace(0,len(pos)-1,20,dtype=int)):
 b=cells[i];b=np.diag(b) if np.asarray(b).shape==(3,3) else b;vals=[]
 for fast in [False,True]:
  l=instance(pos[i],b,H/('fast_parity' if fast else 'base_parity'),fast);l.command('thermo_style custom step pe pxx pyy pzz pxy pxz pyz');l.command('run 0');E=l.get_thermo('pe')*4.184;F=np.array(l.gather_atoms('f',1,3)).reshape(-1,3)*4.184;W=np.array([l.get_thermo(k) for k in ['pxx','pyy','pzz','pxy','pxz','pyz']])*1.01325*np.prod(b)/16605.39067;l.close();vals.append((E,F,W))
 rows.append({'frame':int(i),'energy_abs_error_kJ_mol':float(abs(vals[0][0]-vals[1][0])),'force_max_abs_error_kJ_mol_A':float(abs(vals[0][1]-vals[1][1]).max()),'six_virial_max_abs_error_kJ_mol':float(abs(vals[0][2]-vals[1][2]).max())})
passed=all(r['energy_abs_error_kJ_mol']<1e-8 and r['force_max_abs_error_kJ_mol_A']<1e-8 and r['six_virial_max_abs_error_kJ_mol']<1e-8 for r in rows);r={'status':'parity_passed_pending_NVE' if passed else 'failed','rows':rows,'primarysha':hashlib.sha256((B/'round6_fit/selected_candidate.json').read_bytes()).hexdigest(),'aliassha':hashlib.sha256(M.read_bytes()).hexdigest(),'fastsource_sha256':hashlib.sha256((H/'fast_kernel/cg_moment_fast.cpp').read_bytes()).hexdigest(),'fastbinary_sha256':hashlib.sha256(plugin.read_bytes()).hexdigest(),'scope':'Exactkernelfusion/zerotailskip, notpotentialretuning. Oneboundedoptimizationattempt.'};(H/'FAST_QUALIFICATION.json').write_text(json.dumps(r,indent=2));assert passed
x=pos[-1];b=cells[-1];b=np.diag(b) if np.asarray(b).shape==(3,3) else b;l=instance(x,b,H/'fast_nve_smoke',True);l.commands_list(['timestep 1','velocity all create 298.15 917531 mom yes rot no dist gaussian','fix integration all nve','run 0']);e0=l.get_thermo('etotal')*4.184;trace=[]
for _ in range(100):
 l.command('run 20 pre no post no');trace.append([l.get_thermo('etotal')*4.184,l.get_thermo('temp')])
y=np.array(l.gather_atoms('x',1,3)).reshape(-1,3);l.close();trace=np.array(trace);N=len(x);drift=float((trace[-1,0]-e0)/N);erange=float(np.ptp(np.r_[e0,trace[:,0]])/N);r.update({'status':'passed' if abs(drift)<.01 and erange<.02 and np.isfinite(y).all() else 'failed','NVE_duration_ps':2,'dt_fs':1,'drift_kJ_mol_bead':drift,'energy_range_kJ_mol_bead':erange,'mean_temperature_K':float(trace[:,1].mean()),'all_finite':bool(np.isfinite(y).all())});(H/'FAST_QUALIFICATION.json').write_text(json.dumps(r,indent=2));print(json.dumps({'status':r['status'],'max_errors':{k:max(row[k] for row in rows) for k in rows[0] if k!='frame'},'drift':drift,'energy_range':erange},indent=2));assert r['status']=='passed'
