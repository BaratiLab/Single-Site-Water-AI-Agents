import json
import numpy as np
from native import create,isolated_energy_kJ_mol,H
m=json.load(open(H.parent/'round5_fit/selected_candidate.json'));m['angular_weight']={'coefficients_ascending':[.3,.7,-.25,.1]+[0.]*10+[.02]};z=np.load(H.parent/'round3_fit/c08_state0/trajectory.npz');x=z['positions_A'][-1];box=float(z['box_A'])
def calc(m,x,b,old=False):
 l=create(m,x,b,H/'checktmp')
 if old:l.commands_list([f'plugin load {H.parent}/round5_poly_engine/cg_moment.dylib','pair_style cg/polyadapt',f'pair_coeff * * {H}/checktmp.params'])
 l.command('thermo_style custom step pe press pxx pyy pzz pxy pxz pyz');l.command('run 0');E=l.get_thermo('pe')*4.184;F=np.asarray(l.gather_atoms('f',1,3)).reshape(-1,3)*4.184;P=np.array([l.get_thermo(a) for a in ['pxx','pyy','pzz','pxy','pxz','pyz']]);W=l.get_thermo('press')*1.01325*b**3*3/16605.39067;l.close();return E,F,W,P
base=calc(m,x,box);old=calc(m,x,box,True);out={'zero_extension_old_polyadapt_parity':{'energy':abs(base[0]-old[0]),'force':float(abs(base[1]-old[1]).max()),'virial':abs(base[2]-old[2])}};assert max(out['zero_extension_old_polyadapt_parity'].values())<1e-8
m['angular_polynomial']={'l0':210.,'l1':-25.,'l2':18.,'nref':1.8};m['embedding']['h3']=-.7;m['embedding']['h4']=.8;E,F,W,P=calc(m,x,box)
d=x[None,:,:]-x[:,None,:];d-=box*np.round(d/box);r=np.linalg.norm(d,axis=2);np.fill_diagonal(r,np.inf);s=np.where(r<m['angular_cutoff_A'],np.maximum(0,1-r*r/m['angular_cutoff_A']**2),0);Q=np.polynomial.polynomial.polyval(s,m['angular_weight']['coefficients_ascending']);w=s**3*Q**2;u=np.divide(d,r[:,:,None],out=np.zeros_like(d),where=np.isfinite(r[:,:,None]));pp=np.einsum('ij,ija->ia',w,u);QQ=np.einsum('ij,ija,ijb->iab',w,u,u);A=.5*((QQ*QQ).sum((1,2))+2*(pp*pp).sum(1)/3+w.sum(1)**2/9-16*(w*w).sum(1)/9);n=np.where(r<5,np.maximum(0,1-r*r/25)**3,0).sum(1);delta=n-m['embedding']['n0'];lc=m['angular_coordination'];Lold=m['lambda_kJ_mol']*(1+lc['b']*(n-lc['nref']))**2;Lnew=210-25*(n-1.8)+18*(n-1.8)**2;added=np.sum((Lnew-Lold)*A-.7*delta**3+.8*delta**4);out['independent_added_energy_error']=float(abs(E-base[0]-added));assert out['independent_added_energy_error']<1e-8
h=1e-5;errs=[]
for i,a in [(0,0),(1,2),(4,1),(31,0),(63,2)]:
 xp=x.copy();xm=x.copy();xp[i,a]+=h;xm[i,a]-=h;fd=-(calc(m,xp,box)[0]-calc(m,xm,box)[0])/(2*h);errs.append(abs(fd-F[i,a]))
wp=calc(m,x*(1+h),box*(1+h))[0];wm=calc(m,x*(1-h),box*(1-h))[0];out['force_FD_max_kJ_mol_A']=float(max(errs));out['isotropic_virial_FD_error_kJ_mol']=float(abs(W+(wp-wm)/(2*h)));out['net_force']=float(np.linalg.norm(F.sum(0)));out['translation_E_error']=abs(calc(m,x+[.7,1.1,-.3],box)[0]-E);out['permutation_E_error']=abs(calc(m,x[::-1],box)[0]-E);rot=calc(m,x[:,[1,2,0]],box);out['rotation_E_error']=abs(rot[0]-E);out['rotation_force_error']=float(abs(rot[1]-F[:,[1,2,0]]).max());assert max(errs)<1e-5 and out['isotropic_virial_FD_error_kJ_mol']<1e-3
xc=np.array([[8,8,8],[10.8,8.3,8.1],[8.4,10.7,8.5],[8.2,8.8,10.8],[11.1,10.9,10.2]],float);b=30.;Pc=calc(m,xc,b)[3];err=[];h=1e-6
for a,beta in [(0,0),(1,1),(2,2),(0,1),(0,2),(1,2)]:
 xp=xc.copy();xm=xc.copy();xp[:,a]+=h*xc[:,beta];xm[:,a]-=h*xc[:,beta];fd=(calc(m,xp,b)[0]-calc(m,xm,b)[0])/(2*h);err.append(float(abs(fd+Pc[len(err)]*1.01325*b**3/16605.39067)))
out['xx_yy_zz_xy_xz_yz_strain_FD_errors_kJ_mol']=err;assert max(err)<1e-4
iso=calc(m,np.array([[10.,10.,10.]]),30.);out['isolated_native_analytic_energy_kJ_mol']=[iso[0],isolated_energy_kJ_mol(m)];assert abs(iso[0]-isolated_energy_kJ_mol(m))<1e-10
from native import run
res=run(m,x,box,H/'nve_smoke',T=298.15,steps=2000,equil=0,sample=20,dt_fs=1.,ensemble='nve');out['NVE_2ps_1fs_drift_kJ_mol_per_bead']=float((res['total_kJ_mol'][-1]-res['total_kJ_mol'][0])/len(x));out['NVE_range_kJ_mol_per_bead']=float(np.ptp(res['total_kJ_mol'])/len(x));out['test_angular_polynomial']=m['angular_polynomial'];out['test_embedding_h3_h4']=[-.7,.8];out['test_Q_degree']=len(m['angular_weight']['coefficients_ascending'])-1;out['status']='passed';(H/'MECHANICS.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
