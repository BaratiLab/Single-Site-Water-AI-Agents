# mW original published SW parameters; real units
MW MW MW 6.189 2.3925 1.8 23.15 1.2 -0.3333333333333333 7.049556277 0.6022245584 4 0 0
