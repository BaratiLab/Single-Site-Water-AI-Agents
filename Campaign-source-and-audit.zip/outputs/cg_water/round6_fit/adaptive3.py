from batch1 import *
PROMPT=B/'round6_llmsr/native_batch2/next_prompt.txt'
CONFIGS=[(8,-12,2,1,None),(10,-12,2,1,None),(8,-20,4,1,None),(10,-20,4,1,None),(8,-5,1,.8,None),(8,-5,1,.65,None),(8,-12,2,1,(150,30)),(8,-12,2,1,None)]
def prepare3():
 specs=json.loads((D/'BATCH1_SPECS.json').read_text())
 for q,(source,K2,h4,scale,coupling) in enumerate(CONFIGS,16):
  psrc=D/f'candidate_{source:02d}.json';m=json.loads(psrc.read_text());m['embedding'].update(K2=K2,h3=0,h4=h4);m['pair_coefficients_descending']=(np.array(m['pair_coefficients_descending'])*scale).tolist();a=m['angular_polynomial'];a.update(l0=a['l0']*scale,l1=a['l1']*scale,l2=a['l2']*scale)
  if coupling:a.update(l1=coupling[0],l2=coupling[1])
  m['undercoordination'].update(nstar=(.8039 if q==23 else .5),A3=0,A4=0);z=np.load(D/f'q{source:02d}_s0/trajectory.npz');frames=z['positions_A'][-8::2];L=float(z['cell_A'][0,0]);eps=1e-4
  def metrics(mm):
   en=[];pp=[]
   for x in frames:
    E=energy(mm,x,L)[0];u=(energy(mm,x,L,np.exp(eps))[0]-energy(mm,x,L,np.exp(-eps))[0])/(2*eps);en.append(E/64);pp.append(-u/(3*L**3)*16605.39067+63*kb*298.15/L**3*16605.39067)
   return np.array([np.mean(pp),isolated(mm)-np.mean(en)+kb*298.15])
  base=metrics(m);mk=copy.deepcopy(m);mk['embedding']['K1']+=1;mg=copy.deepcopy(m);mg['undercoordination']['A4']+=1;J=np.column_stack((metrics(mk)-base,metrics(mg)-base));delta=np.linalg.lstsq(J,np.array([1,43.98748])-base,rcond=None)[0];delta=np.clip(delta,[-10,0],[10,80]);m['embedding']['K1']+=float(delta[0]);m['undercoordination']['A4']=float(delta[1]);m['round6_adaptive3_provenance']={'parent_path':str(psrc),'parent_sha256':hashlib.sha256(psrc.read_bytes()).hexdigest(),'feedback_prompt':str(PROMPT),'feedback_prompt_sha256':hashlib.sha256(PROMPT.read_bytes()).hexdigest(),'fixed_nstar':m['undercoordination']['nstar'],'nstar_rationale':'Below approximately1% nativeMWbaseline training coordination; sparsely liquid-active, no vapor accuracy claim. Selected before these proposals.','static_base':base.tolist(),'deltaK1_A4':delta.tolist(),'static_prediction':(base+J@delta).tolist(),'rationale':'Actual batch2 pair-well cohesion compensation stiffenedEOS. Replace compensation by sparse lower-coordination term; stronger stabilized negative quadratic softens EOS; joint radial/angular co-scaling tests balanced network strength. ActualMDrequired.'};p=D/f'candidate_{q:02d}.json';p.write_text(json.dumps(m,indent=2));specs.append({'q':q,'seed_family':1,'structure_label':f'feedback_sparse_underA4_softK{K2}_quartic{h4}_radialAngularScale{scale}_L1{a["l1"]}','path':str(p)})
 (D/'BATCH1_SPECS.json').write_text(json.dumps(specs,indent=2))
if __name__=='__main__':
 if sys.argv[1]=='prepare':prepare3()
 else:
  for q in range(16+int(sys.argv[1]),24,2):evaluate(q)
