from pathlib import Path
import json,numpy as np,matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
D=Path(__file__).resolve().parent;B=D.parent;c=json.loads((D/'COMPARISON.json').read_text());H=[B/'round5_validation',B/'round6_mw_comparison',D];names=['Previous round 5','Native mW','Frozen candidate'];cols=['#7b8796','#4267a5','#087e8b'];es=[json.loads((p/'eos/REPORT.json').read_text())['EOS'] for p in H];plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42});fig,aa=plt.subplots(2,2,figsize=(11,6.8),layout='constrained');ax=aa.ravel()
for p,name,col in zip(H[1:],names[1:],cols[1:]):
 r=np.load(p/'experimental295/RDF_COMPARISON.npz');ax[0].plot(r['r_A'],r['g'],color=col,label=name)
r=np.load(D/'experimental295/RDF_COMPARISON.npz');x=r['r_A'];ref=r['experimental_shell_average'];err=r['author_estimated_error_shellaverage'];ax[0].plot(x,ref,color='#bd7b1e',label='Experimental shell average');ax[0].fill_between(x,ref-err,ref+err,color='#bd7b1e',alpha=.18,label='Author estimated-error band');ax[0].set(xlim=(2.4,5.8),xlabel='O–O separation (Å)',ylabel='g(r)');ax[0].legend(frameon=False,fontsize=8)
for j,(key,ci,mul,target,label) in enumerate([('kappa_bar_inverse','bootstrap95_kappa',1e5,4.524632587,'Compressibility (10⁻⁵ bar⁻¹)'),('alpha_K_inverse','bootstrap95_alpha',1e4,2.57287426,'Expansion (10⁻⁴ K⁻¹)'),('dP_dT_bar_per_K','bootstrap95_dP_dT',1,5.6863717,'Pressure–temperature coefficient (bar K⁻¹)')],1):
 for i,e in enumerate(es):
  ax[j].bar(i,e[key]*mul,color=cols[i],width=.65);unc=c['uncertainties'][['Compressibility,EOS','Expansion,EOS','Pressure-temperature coefficient,EOS'][j-1]][['previous_round5','native_mW','new_candidate'][i]]['CI95_descriptive'];ax[j].vlines(i,unc[0]*mul,unc[1]*mul,color='black',linewidth=1)
 ax[j].axhline(target,color='#333',linestyle='--',linewidth=1,label='IAPWS liquid');ax[j].set_xticks(range(3),['Previous','mW','Candidate']);ax[j].set_ylabel(label);ax[j].legend(frameon=False,fontsize=8,loc='upper left')
for j,a in enumerate(ax):a.text(0,1.025,chr(65+j),transform=a.transAxes,va='bottom',fontweight='bold')
fig.suptitle('Independent frozen-candidate comparison • 512 beads\nExperimental RDF: matched 295.15 K state • bulk EOS: 298.15 K • lines: descriptive 95% block-bootstrap intervals',fontsize=11);fig.savefig(D/'INDEPENDENT_COMPARISON.png',dpi=220);fig.savefig(D/'INDEPENDENT_COMPARISON.pdf')
