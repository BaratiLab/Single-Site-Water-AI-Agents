from pathlib import Path
import os
os.environ.setdefault("MPLCONFIGDIR",str(Path(__file__).resolve().parent/".mplcache"))
import json,numpy as np,matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
D=Path(__file__).resolve().parent;rows=[json.loads(p.read_text()) for p in sorted(D.glob('TRIAL_*.json'))];large=[json.loads(p.read_text()) for p in sorted(D.glob('N512_TRIAL_*.json'))];colors=plt.get_cmap('tab10').colors
plt.rcParams.update({'font.size':9,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42})
f,ax=plt.subplots(1,3,figsize=(13.2,3.6),layout='constrained')
for i,r in enumerate(rows):
 q=int(r['trial_id'][-2:]);grp=0 if q<2 else 1 if q<8 else 2 if q<16 else 3 if q<24 else 4 if q<28 else 5;ax[0].scatter(q,min(r['objective_value'],100),color=colors[grp],s=24,marker='v' if r['objective_value']>100 else'o')
ax[0].axhline(1,color='black',ls='--',lw=1);ax[0].set(yscale='log',xlabel='N64 candidate index',ylabel='Worst normalized property discrepancy',title='a  Bounded training search',ylim=(.7,150));ax[0].text(.03,.11,'Research gate: discrepancy ≤1',transform=ax[0].transAxes,fontsize=8)
ax[1].add_patch(Rectangle((3.393,1.286),2.263,2.573,color='#d7edd4',zorder=0));ax[1].scatter([r['properties']['kappa_bar_inverse']*1e5 for r in rows],[r['properties']['alpha_K_inverse']*1e4 for r in rows],s=10,color='.8',label='N64 pilot',zorder=1)
for i,r in enumerate(large):
 q=int(r['trial_id'][-2:]);col='#087abf' if q==34 else '#d97825' if q==33 else '.55';p=r['properties'];x=p['kappa_bar_inverse']*1e5;y=p['alpha_K_inverse']*1e4;ci=r.get('diagnostic_block_bootstrap_95_percentiles',{});cx=ci.get('kappa_bar_inverse',[x/1e5,x/1e5]);cy=ci.get('alpha_K_inverse',[y/1e4,y/1e4]);ax[1].errorbar(x,y,xerr=[[max(0,x-cx[0]*1e5)],[max(0,cx[1]*1e5-x)]],yerr=[[max(0,y-cy[0]*1e4)],[max(0,cy[1]*1e4-y)]],color=col,alpha=.45,lw=.9,capsize=2,zorder=2);ax[1].scatter(x,y,s=55,color=col,label=('Primary c34' if q==34 else 'Strict minmax c33' if q==33 else 'Other N512 trials' if i==0 else None),zorder=4);ax[1].annotate(r['trial_id'].split('_')[-1],(x,y),xytext=(4,4),textcoords='offset points',fontsize=8,color=col)
ax[1].scatter(4.52463,2.57287,marker='*',s=110,color='black',zorder=5,label='Experiment');ax[1].set(xlim=(0,8),ylim=(-5,7),xlabel=r'$\kappa_T$ ($10^{-5}$ bar$^{-1}$)',ylabel=r'$\alpha_P$ ($10^{-4}$ K$^{-1}$)',title='b  Larger-cell EOS training');ax[1].legend(frameon=False,fontsize=7,loc='lower right')
ref=None
for i,r in enumerate(large):
 q=int(r['trial_id'][-2:]);z=np.load(D/f'N512_RDF_{q:02d}.npz');rr=z['r_A'];ref=z['target'];ax[2].plot(rr,z['g'],color=('#087abf' if q==34 else '#d97825' if q==33 else '.65'),lw=(2 if q==34 else 1.5 if q==33 else .8),alpha=(1 if q in [33,34] else .45),label=('Primary c34' if q==34 else 'Strict minmax c33' if q==33 else 'Other N512 trials' if i==0 else None),zorder=(5 if q==34 else 4 if q==33 else 1))
if ref is not None:ax[2].plot(rr,ref,'k',lw=1.5,label='Skinner2013, 295.15K')
ax[2].set(xlim=(2.3,5.8),ylim=(0,3.5),xlabel=r'$r$ (Å)',ylabel=r'$g_{OO}(r)$',title='c  Matched-temperature RDF');ax[2].legend(frameon=False,fontsize=7)
f.savefig(D/'TRAINING_PROGRESS.png',dpi=220);f.savefig(D/'TRAINING_PROGRESS.pdf')
