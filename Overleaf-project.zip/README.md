# Agentic Swarm Discovery of Single-Site Water Molecule

New, separate manuscript project for the neutral single-site c34 water prototype. The earlier three-site Overleaf paper is unchanged.

- Main document: `main.tex`.
- Supplementary Information: select `supplement.tex` as main to compile it.
- Full-precision primary parameters: `model/frozen_c34.json` and `model/radial_coefficients.csv`.
- Figures: collaboration workflow, training, independent structure/response, and controlled computational cost.
- `evidence/`: compact, unchanged reports and model/selection audits. Absolute paths in evidence retain historical provenance.
- `lammps/`: original analytic serial kernel, exporter, build script, ABI header/license, frozen parameters and starting coordinates. Rebuild against a compatible installed LAMMPS; adapt paths after extraction. See the local smoke record and reproduction notes.

Scientific status: all broad primary mean gates pass; overall pressure/thermal response is NOT QUALIFIED. No native-mW speed advantage, c34 diffusion, phase-coexistence, dielectric, or universal-water claim. The selected c34 uses an explicit pre-holdout training selection amendment; c33 remains the original strict-minimax winner. No fresh test data retuned c34. The polynomial-mW seed is literature-informed; this round has no new AIMD training.

Raw MD trajectories and runtime-specific binaries are omitted. This project supports model inspection/basic MD reproduction with external dependencies, but not complete trajectory-based reanalysis. Full local campaign review archive: `outputs/CG_Water_Round6_Review.zip` in the original workspace.

This is a research draft for author review; the author list is provisional. AI assistance and the bounds of the LLM-SR adapter are disclosed. No controlled swarm-ablation or first-ever priority is claimed.
