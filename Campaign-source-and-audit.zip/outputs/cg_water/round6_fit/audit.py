from pathlib import Path
import json,hashlib,time
D=Path(__file__).resolve().parent;items=[]
for pattern in ['TRIAL_*.json','N512_TRIAL_*.json']:
 for p in D.glob(pattern):
  r=json.loads(p.read_text());m=Path(r['model_path']);q=r['trial_id'][-2:];actual=hashlib.sha256(m.read_bytes()).hexdigest();items.append({'record':p.name,'model_path':str(m),'identity_pass':m.name==f'candidate_{q}.json','hash_pass':actual==r['model_sha256']})
r={'checked_utc':time.time(),'record_count':len(items),'all_pass':all(v['identity_pass'] and v['hash_pass'] for v in items),'excluded_wrong_lookup_directory':'diagnostic_wrong_spec_lookup','items':items};(D/'IDENTITY_HASH_AUDIT.json').write_text(json.dumps(r,indent=2));assert r['all_pass'];print('Identity/hash audit passed',len(items),'records')
