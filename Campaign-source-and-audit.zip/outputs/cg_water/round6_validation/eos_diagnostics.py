"""Predeclared EOS model-misspecification diagnostics; never replace primary gates."""
from pathlib import Path
import json,numpy as np
RHO=.99705;T0=298.15

def summarize(c):
 p,b,t=map(float,c[:3]);return dict(intercept_bar=p,dP_drho_bar_per_g_cm3=b,dP_dT_bar_per_K=t,kappa_bar_inverse=1/(RHO*b),alpha_K_inverse=t/(RHO*b),rho_root_1bar_linearized=RHO+(1-p)/b)

def fit(states,nominal=False):
 r=np.array([s['rho']-RHO for s in states]);t=np.array([s['target_T'] if nominal else s['temperature']['mean'] for s in states])-T0;p=np.array([s['pressure']['mean'] for s in states]);se=np.array([s['pressure']['SE'] for s in states]);i=int(np.argmin(abs(r)+abs(np.array([s['target_T'] for s in states])-T0)))
 X=np.column_stack([np.ones(len(r)),r,t]);c=np.linalg.lstsq(X,p,rcond=None)[0];res=p-X@c
 # Anchor at the measured central state's actual temperature, then evaluate at T0.
 A=np.column_stack([r-r[i],t-t[i]]);bc=np.linalg.lstsq(A,p-p[i],rcond=None)[0];anch=np.array([p[i]-bc[0]*r[i]-bc[1]*t[i],*bc]);ares=p-X@anch
 Z=np.column_stack([np.ones(len(r)),r/.02,t/10,(r/.02)**2,(t/10)**2]);q=np.linalg.lstsq(Z,p,rcond=None)[0];physical=q/np.array([1,.02,10,.02**2,100]);quad=summarize(physical);quad.update(d2P_drho2=2*float(physical[3]),d2P_dT2=2*float(physical[4]),coefficients_order_P0_rho_T_rho2_T2=physical.tolist(),condition_number=float(np.linalg.cond(Z)),rank=int(np.linalg.matrix_rank(Z)),residual_degrees_of_freedom=len(p)-int(np.linalg.matrix_rank(Z)))
 roots=np.roots([physical[3],physical[1],physical[0]-1]) if abs(physical[3])>1e-12 else [(1-physical[0])/physical[1]];quad['quadratic_density_roots_g_cm3']=[float(z.real+RHO) for z in roots if abs(z.imag)<1e-9];quad['density_roots_inside_sampled_interval']=[z for z in quad['quadratic_density_roots_g_cm3'] if .98<=z<=1.015]
 return dict(global_linear={**summarize(c),'residuals_bar':res.tolist(),'state_pressure_SE_bar':se.tolist(),'residual_over_SE':(res/se).tolist(),'max_abs_residual_bar':float(max(abs(res))),'max_abs_residual_over_SE':float(max(abs(res/se)))},central_observed=dict(state_index=i,pressure_bar=float(p[i]),pressure_SE_bar=float(se[i]),temperature_K=float(t[i]+T0),rho_g_cm3=float(r[i]+RHO),global_intercept_minus_observed_bar=float(c[0]-p[i])),central_anchored_linear={**summarize(anch),'residuals_bar':ares.tolist()},quadratic_cross_interpolation=quad)

def diagnostics(states,boot=2000):
 result={'actual_mean_temperature':fit(states),'nominal_temperature':fit(states,True),'qualification':'Primary locked global linear EOS is unchanged. Anchored and exactly identified five-parameter quadratic cross interpolation are sensitivity diagnostics, not independent validation. No rho-temperature cross derivative is identifiable from this design; zero quadratic residual does not establish model adequacy. Residual/SE omits temperature predictor uncertainty. Bootstrap intervals describe finite-block sampling only.'}
 rng=np.random.default_rng(661903);samples={k:[] for k in ['central_anchored_linear','quadratic_cross_interpolation']}
 for _ in range(boot):
  ss=[]
  for s in states:
   n=len(s['pressure']['blocks']);idx=rng.integers(0,n,n);v=dict(s);v['pressure']={**s['pressure'],'mean':float(np.mean(np.array(s['pressure']['blocks'])[idx]))};v['temperature']={**s['temperature'],'mean':float(np.mean(np.array(s['temperature']['blocks'])[idx]))};ss.append(v)
  f=fit(ss)
  for k in samples:samples[k].append([f[k][q] for q in ['intercept_bar','kappa_bar_inverse','alpha_K_inverse','dP_dT_bar_per_K']])
 result['paired_block_bootstrap95_sensitivity']={k:dict(zip(['intercept_bar','kappa_bar_inverse','alpha_K_inverse','dP_dT_bar_per_K'],np.percentile(v,[2.5,97.5],axis=0).T.tolist())) for k,v in samples.items()}
 return result
if __name__=='__main__':
 import argparse
 p=argparse.ArgumentParser();p.add_argument('report',type=Path);p.add_argument('--out',type=Path,required=True);a=p.parse_args();data=json.loads(a.report.read_text());states=data['states'] if isinstance(data,dict) else data;a.out.parent.mkdir(parents=True,exist_ok=True);a.out.write_text(json.dumps(diagnostics(states),indent=2)+'\n')
