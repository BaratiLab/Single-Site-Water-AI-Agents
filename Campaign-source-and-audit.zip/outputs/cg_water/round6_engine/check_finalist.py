"""Explicit future frozen-finalist mechanics gate. Does nothing on import."""
import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS']:os.environ[k]='1'
from pathlib import Path
import argparse,json,hashlib
import numpy as np
from native import create,isolated_energy_kJ_mol,H

def main():
 p=argparse.ArgumentParser();p.add_argument('--model',type=Path,required=True);p.add_argument('--trajectory',type=Path,required=True);p.add_argument('--sha256',required=True);p.add_argument('--output-prefix',type=Path,default=H/'finalist');a=p.parse_args();sha=hashlib.sha256(a.model.read_bytes()).hexdigest()
 if sha!=a.sha256:raise RuntimeError('Frozen model SHA mismatch')
 m=json.load(open(a.model));z=np.load(a.trajectory);x=z['positions_A'][-1].copy();b=z['cell_A'][-1] if 'cell_A' in z else z['box_A'];b=np.diag(b) if np.asarray(b).shape==(3,3) else np.broadcast_to(b,(3,));N=len(x)
 def scalar(x,b,suffix):
  l=create(a.model,x,b,str(a.output_prefix)+suffix);l.command('run 0');E=l.get_thermo('pe')*4.184;F=np.array(l.gather_atoms('f',1,3)).reshape(-1,3)*4.184;W=l.get_thermo('press')*1.01325*np.prod(b)*3/16605.39067;l.close();return E,F,W
 E,F,W=scalar(x,b,'_fd');errs=[];h=1e-5
 for i,j in [(0,0),(N//2,1),(N-1,2)]:
  xp=x.copy();xm=x.copy();xp[i,j]+=h;xm[i,j]-=h;fd=-(scalar(xp,b,'_fd')[0]-scalar(xm,b,'_fd')[0])/(2*h);errs.append(float(abs(fd-F[i,j])))
 hv=1e-6;wp=scalar(x*(1+hv),b*(1+hv),'_fd')[0];wm=scalar(x*(1-hv),b*(1-hv),'_fd')[0];wfd=-(wp-wm)/(2*hv);iso=scalar(np.array([[10.,10.,10.]]),np.array([30.,30.,30.]),'_iso')[0];isoref=isolated_energy_kJ_mol(m)
 l=create(a.model,x,b,str(a.output_prefix)+'_nve');l.commands_list(['timestep 1','velocity all create 298.15 927419 mom yes rot no dist gaussian','fix int all nve','run 0']);e0=l.get_thermo('etotal')*4.184;trace=[]
 for _ in range(200):
  l.command('run 10 pre no post no');trace.append([l.get_thermo('time')*.001,l.get_thermo('etotal')*4.184,l.get_thermo('temp'),l.get_thermo('press')*1.01325])
 y=np.array(l.gather_atoms('x',1,3)).reshape(-1,3);l.close();trace=np.array(trace);d=y[None,:,:]-y[:,None,:];d-=b*np.rint(d/b);r=np.linalg.norm(d,axis=2);np.fill_diagonal(r,np.inf);minimum=float(r.min());drift=float((trace[-1,1]-e0)/N);erange=float(np.ptp(np.r_[e0,trace[:,1]])/N);finite=bool(np.isfinite(trace).all() and np.isfinite(y).all());passed=bool(max(errs)<1e-5 and abs(W-wfd)<max(.001,abs(W)*1e-7) and abs(iso-isoref)<1e-8 and finite and minimum>1.5 and abs(drift)<.01 and erange<.02)
 report={'model_sha256':sha,'model':str(a.model),'initial_trajectory':str(a.trajectory),'initial_trajectory_sha256':hashlib.sha256(a.trajectory.read_bytes()).hexdigest(),'engine_source_sha256':hashlib.sha256((H/'cg_moment.cpp').read_bytes()).hexdigest(),'engine_binary_sha256':hashlib.sha256((H/'cg_moment.dylib').read_bytes()).hexdigest(),'N':N,'force_FD_errors_kJ_mol_A':errs,'scalar_virial_analytic_FD_kJ_mol':[float(W),float(wfd)],'scalar_virial_error_kJ_mol':float(abs(W-wfd)),'gas_native_analytic_kJ_mol':[float(iso),float(isoref)],'net_force_kJ_mol_A':float(np.linalg.norm(F.sum(0))),'NVE_dt_fs':1,'NVE_duration_ps':2,'NVE_drift_kJ_mol_bead':drift,'NVE_range_kJ_mol_bead':erange,'NVE_temperature_mean_range_K':[float(trace[:,2].mean()),float(trace[:,2].min()),float(trace[:,2].max())],'final_min_distance_A':minimum,'status':'passed' if passed else 'failed','qualification':'Shortfrozenfinalistmechanicsgate; notequilibrium,transport,longtimesteporpropertyqualification. No tuning.'};Path(str(a.output_prefix)+'_MECHANICS.json').write_text(json.dumps(report,indent=2));np.savez_compressed(str(a.output_prefix)+'_NVE_TRACE.npz',time_ps=trace[:,0],total_energy_kJ_mol=trace[:,1],temperature_K=trace[:,2],pressure_bar=trace[:,3]);print(json.dumps(report,indent=2));return 0 if passed else 1
if __name__=='__main__':raise SystemExit(main())
