from pressure_polish import *
CONFIGS=[(16,'1.2'),(16,'1.5'),(20,'1.2'),(20,'1.5')]
def prepare():
 specs=json.loads((D/'BATCH1_SPECS.json').read_text());prompt=B/'round6_llmsr/native_batch3/next_prompt.txt'
 for q,(parent,soft) in enumerate(CONFIGS,24):
  src=B/f'round6_reference/softness_c{parent}_{soft}.json';m=json.loads(src.read_text());m['round6_feedback']={'prompt_path':str(prompt.resolve()),'prompt_sha256':hashlib.sha256(prompt.read_bytes()).hexdigest(),'hypothesis':'Actual24screens show negativeembeddingalonefailsEOSsoftness. Coordinatewarp changesradialcurvatureindependentlyfromwelldepth. Rawliteratureinitializedpolynomialfamily, actualpressureMDsecantrequired.'};p=D/f'RAW_proposal_{q:02d}.json';p.write_text(json.dumps(m,indent=2));specs.append({'q':q,'seed_family':1,'structure_label':f'feedback_radial_coordinate_warp_softness{soft}_parentc{parent}_actual_pressure_secant_sparseA4','path':str(D/f'candidate_{q:02d}.json')})
 (D/'BATCH1_SPECS.json').write_text(json.dumps(specs,indent=2))
if __name__=='__main__':
 if sys.argv[1]=='prepare':prepare()
 else:
  for q in range(24+int(sys.argv[1]),28,2):
   parent=CONFIGS[q-24][0];polish(q,D/f'RAW_proposal_{q:02d}.json',parent);evaluate(q)
