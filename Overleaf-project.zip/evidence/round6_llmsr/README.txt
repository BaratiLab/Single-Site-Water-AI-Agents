ROUND 6 LLM-SR AUDIT AND SCOPE

The vendored upstream LLM-SR commit is41c212312df6c16d936c9cb395356a62774c47e3.
The actual Sampler, Evaluator, ExperienceBuffer and code_manipulation modules are used. The current language-model agents author literal function-family proposals in files, inspect native feedback prompts between adaptive batches, and run fitting/MD outside the framework. A file-sampler adapter replays those continuations through the native interface. This is not a separate external LLM API search, nor a claim that LLM-SR itself ran or differentiated MD.

native_batch1 through native_batch7 preserve intermediate feedback snapshots. native_final registers all40 recorded training evaluations (39 continuations plus seed), including repeated model identities at different cell sizes/budgets. There are35 distinct candidate parameter sets,32 N64 screens and8 N512 refinements. The evaluator checks each source model SHA256 before returning recorded measured fitness. Excluded wrong-lookup runs and the rejected Born estimator are not candidate fitness. Native buffer rankings mix stages and must not be used to choose the final model.

Same-budget N512 strict-minimax training ranking selects c33. The primary frozen c34 is instead selected by a separately recorded adaptive pre-holdout density-risk amendment among two mean-feasible candidates; see round6_summary/SELECTION_AMENDMENT.json and round6_fit/FREEZE.json. This amendment is not concealed as the original selection rule. No candidate holdout data is fed back into fitting or native_final. All fresh validation is a later, independent stage.

Reproduction of the final buffer from the retained audit:
  OPENBLAS_NUM_THREADS=1 python outputs/cg_water/round6_llmsr/prepare.py
  OPENBLAS_NUM_THREADS=1 python outputs/cg_water/round6_llmsr/run_llmsr.py --proposals outputs/cg_water/round6_llmsr/proposals.json --evaluator outputs/cg_water/round6_llmsr/evaluator.py --out /tmp/round6_llmsr_replay

The replay verifies model hashes and cached measured scores; it does not rerun simulations. Raw MD and source scripts are available separately in this workspace. Native prompt snapshots document a bounded adaptive search, not an exhaustive/global symbolic optimum. See upstream LICENSE in the included vendor tree.
