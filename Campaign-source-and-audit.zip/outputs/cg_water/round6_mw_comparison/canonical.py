from pathlib import Path
import json,hashlib,numpy as np
D=Path(__file__).resolve().parent;p=D/'eos/state1.npz'
if not p.exists():raise SystemExit('Wait for ambient EOS state')
a=np.load(p);N=a['positions_A'].shape[1];T=298.15;KB=.008314462618;PV=.0000602214076;U=a['potential_kJ_mol'];V=a['volume_A3'];pc=a['pressure_bar']-(N-1)*KB*a['temperature_K']/(V*PV)
def calc(u,v,p):return {'CG_Cv_J_mol_K':float(np.var(u,ddof=1)/(N*KB*T*T)*1000+(3*N-3)/(2*N)*KB*1000),'canonical_dP_dT_bar_per_K':float((N-1)*KB/(np.mean(v)*PV)+np.cov(p,u,ddof=1)[0,1]/(KB*T*T))}
r=calc(U,V,pc);b=[calc(*q) for q in zip(np.array_split(U,8),np.array_split(V,8),np.array_split(pc,8))];r['eight_blocks']=b;r['eightblock_SE_descriptive']={k:float(np.std([z[k] for z in b],ddof=1)/np.sqrt(8)) for k in b[0]};r['source_SHA256']=hashlib.sha256(p.read_bytes()).hexdigest();r['scope']='Independent512NVT60ps, fixedrho.99705, canonical covariance response; CGheatcapacityincludesCOM-correctedtranslationbutnoteliminatedmoleculardegrees. Sampling-sensitivecovariancecrosscheck,notselectedreplacementforEOS/NPT.'
(D/'CANONICAL_RESPONSE.json').write_text(json.dumps(r,indent=2));print(json.dumps(r))
