# cg/joint: independently adjustable angular value, slope and curvature

Unique GPL-2.0-or-later serial native research plugin. Previous engine directories and binaries are unchanged. This adds general positive-quadratic angular strength and stabilized higher-order coordination embedding to the existing polynomial angular-weight family.

For delta=n−nref, the optional angular coefficient is

L(n)=l0+l1*delta+l2*delta²,
L'(n)=l1+2*l2*delta.

JSON:

```
"angular_polynomial": {"l0": 210.0, "l1": -25.0, "l2": 18.0, "nref": 1.8}
```

l0/l1/l2 are in kJ/mol because coordination is dimensionless. When this object is present it replaces the older lambda*(1+b*delta)² expression. Native guards require l0>0, l2>=0, and l1²<4*l0*l2 for l2>0. A positive constant with l1=l2=0 is allowed. Thus L is strictly positive for every real coordination, not merely the training interval.

When angular_polynomial is absent, the exact previous square expression and its analytic derivative remain unchanged. Mapping an old square to l0=lambda, l1=2*lambda*b, l2=lambda*b² gives zero discriminant; it must stay in the legacy schema or be adjusted to strict positivity before using the new schema. No silent coefficient alteration is applied by the exporter.

Embedding now optionally includes

```
"embedding": {"K2": ..., "K1": ..., "n0": ..., "rd": ..., "h3": -0.7, "h4": 0.8}
```

The extra energy is h3*(n−n0)³+h4*(n−n0)⁴, and its derivative is included analytically. h4 must be nonnegative; nonzero h3 requires strictly positive h4 for quartic stabilization. This does not guarantee convexity of the complete embedding function. The earlier undercoordination penalty and its guards remain unchanged.

The existing angular weight w=s³*Q(s)² and ascending polynomial coefficients are retained, with degrees0–16 supported. The implemented exact-moment invariant A_i is multiplied by L(n_i). Forces include L'(n_i)*A_i through the coordination gradient and L(n_i)*gradient(A_i). Radial spline updates require only new JSON coefficients, not new engine source.

## API and parameter layout

`native.py` retains export/create/run and adds no new integration machinery. Pair style is `cg/joint`. Its ASCII parameter format appends

`use_general_polynomial l0 l1 l2 nref h3 h4`

after all previous fields, including the Q polynomial degree/coefficients. Missing new fields preserve old behavior. Optional object defaults are l1=l2=0, nref=embedding.n0; l0 is required when the angular_polynomial object is present. h3=h4 default to zero.

The isolated-bead reference becomes

E_iso=K2*n0²−K1*n0−h3*n0³+h4*n0⁴+A3+A4.

Use `isolated_energy_kJ_mol(model)` when computing cohesion diagnostics. Angular terms vanish for an isolated bead.

## Implementation evidence

MECHANICS.json tests a nontrivial degree14 angular weight, independent angular quadratic, nonzero stabilized cubic/quartic embedding, and all legacy terms. Old-family energy/force/virial parity is exactly zero. Independent added-energy error3.83e-13kJ/mol; force finite-difference error1.27e-7kJ/mol/Angstrom; six-component strain virial maximum diagonal1.68e-5 and shear3.60e-6kJ/mol. Translation/permutation/cubic-rotation and net-force checks pass. Actual isolated-bead reference matches exactly. A2ps NVE smoke at1fs has drift−3.71e-5kJ/mol/bead. These are mechanics tests, not fitted water-property validation.

Build/check from project root:

```
PYTHONPATH=work/lammps_runtime python outputs/cg_water/round6_engine/build_plugin.py
PYTHONPATH=work/lammps_runtime OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 python outputs/cg_water/round6_engine/check.py
```

LAMMPS-linked source retains GPL notices. Matching external LAMMPS headers, shared library and C++17 compiler are required; the plugin ABI header and license are copied locally. Current convenience API loads the macOS dylib. Serial orthogonal periodic real-unit cells, one bead species only; every box length must exceed twice the largest cutoff throughout MD. No MPI, triclinic, restart, per-atom stress or heat-current qualification. No concurrent force-cost benchmark has been run.

## Additional admission guard

Negative K2 is admitted only with strictly positive h4. Both Python export and native parameter reading enforce this independently; STABILITY_GUARD_CHECK.json records zero-timestep rejection/acceptance tests. The finite short-distance radial core does not by itself prove stability against an increasingly coordinated many-particle collapse with negative quadratic embedding. A positive quartic removes that obvious unbounded coordination-polynomial direction. This conservative admission rule is not a complete proof of thermodynamic/Ruelle stability for every parameter set.

The guarded library was installed only after the fitter confirmed no cg/joint MD was live and held its next launch. No running model was modified. Force/energy expressions for previously admissible parameters are unchanged.

`check_finalist.py` is prepared for a future explicit freeze. It requires --model, --trajectory and --sha256, verifies that exact model, then runs selected force/isotropic virial/gas-reference checks and2ps NVE at1fs. It does nothing on import and has not been executed before a new finalist is frozen. Generic full six-component strain checks remain in check.py.
