"""Compact review bundle; raw training trajectories remain in the workspace."""
from pathlib import Path
import json,hashlib,zipfile
D=Path(__file__).resolve().parent;root=D.parents[2]
allowed={'.py','.cpp','.h','.json','.txt','.md','.csv','.png','.svg','.pdf','.in','.template','.sw','.dylib','.so','.params'}
files=[]
for folder in sorted((root/'outputs/cg_water').glob('round6_*')):
 if not folder.is_dir():continue
 for p in sorted(folder.rglob('*')):
  if not p.is_file() or '__pycache__' in p.parts:continue
  if p.suffix in allowed or p.name.startswith('LICENSE') or (p.suffix=='.npz' and ('rdf' in p.name.lower() or 'skinner' in p.name.lower() or p.name.startswith('RDF') or 'TRACE' in p.name or 'snapshot' in p.name.lower())) or p.name in {'frozen_start512.data','common512.data'}:files.append(p)
for folder in [root/'outputs/v2/vendor',root/'outputs/v5/lammps_vendor']:
 for p in folder.rglob('*'):
  if p.is_file() and '__pycache__' not in p.parts and (p.suffix in {'.py','.txt','.h'} or 'LICENSE' in p.name):files.append(p)
for rel in ['outputs/cg_water/round5_mw_poly/candidate.json','outputs/cg_water/round5_validation/COMPARISON.json','outputs/cg_water/round5_validation/eos/REPORT.json','outputs/cg_water/round5_validation/ambient/REPORT.json','outputs/v7/round7_rdf/rdf_1_OO.npz']:
 files.append(root/rel)
files=[p for p in files if p!=D/'BUNDLE_MANIFEST.json']
manifest={'scope':'Compact review/source bundle. Raw MD logs/trajectories remain in the original workspace; training/failure records identify their paths. Basic frozen-model reproduction materials are included. External compatible LAMMPS/Python installation required.', 'files':[{'path':str(p.relative_to(root)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]}
(D/'BUNDLE_MANIFEST.json').write_text(json.dumps(manifest,indent=2));files.append(D/'BUNDLE_MANIFEST.json')
out=root/'outputs/CG_Water_Round6_Review.zip'
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in files:z.write(p,p.relative_to(root))
with zipfile.ZipFile(out) as z:
 assert all(hashlib.sha256(z.read(q['path'])).hexdigest()==q['sha256'] for q in manifest['files'])
print(json.dumps({'archive':str(out),'bytes':out.stat().st_size,'files':len(files),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'all_included_file_hashes_verified':True}))
