from pathlib import Path
import json,numpy as np
D=Path(__file__).resolve().parent
rows=[]
for p in sorted(D.glob('N512_TRIAL_*.json')):
 q=int(p.stem[-2:]);m=json.loads(Path(json.loads(p.read_text())['model_path']).read_text());z=np.load(D/f'N512_q{q:02d}_s0/trajectory.npz');rd=m['embedding']['rd'];L=float(z['cell_A'][0,0]);alln=[];mins=[];sf=[]
 for x in z['positions_A'][::30]:
  d=x[:,None,:]-x[None,:,:];d-=L*np.rint(d/L);r2=np.sum(d*d,axis=2);np.fill_diagonal(r2,np.inf);alln.extend(np.sum(np.maximum(0,1-r2/rd**2)**3,axis=1));mins.append(float(np.sqrt(r2.min())));sf.append(float(np.mean(np.abs(np.exp(2j*np.pi*x/L).sum(axis=0))**2)/len(x)))
 rows.append({'trial_id':q,'coordination_mean':float(np.mean(alln)),'coordination_std':float(np.std(alln)),'coordination_quantiles':np.quantile(alln,[0,.01,.05,.5,.95,.99,1]).tolist(),'minimum_r_A':float(min(mins)),'smallest_axis_structure_factor_mean':float(np.mean(sf)),'smallest_axis_structure_factor_range':[float(min(sf)),float(max(sf))],'scope':'Ambientfiniteboxdiagnostic,notproofphasestability; smallestthreeCartesianwavevectors,10sampledframes.'})
(D/'STABILITY_DIAGNOSTICS.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rows,indent=2))
