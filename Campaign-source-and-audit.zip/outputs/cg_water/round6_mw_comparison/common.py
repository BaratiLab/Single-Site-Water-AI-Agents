from pathlib import Path
import json,hashlib,numpy as np
D=Path(__file__).resolve().parent;KB=.008314462618;N=512;PV=.0000602214076;R=KB*1000;KIN=1.5*(1-1/N)

def stats(x):
 b=np.array([q.mean() for q in np.array_split(x,10)])
 z=x-np.mean(x);ac=np.fft.irfft(abs(np.fft.rfft(z,n=2*len(z)))**2)[:len(z)];ac/=np.arange(len(z),0,-1);ac/=ac[0];stop=np.flatnonzero(ac[1:]<=0);last=int(stop[0]+1) if len(stop) else len(x)//2;tau=max(.5,.5+np.sum(ac[1:last]));halfse=[np.std(q,ddof=1)/np.sqrt(len(q)) for q in np.array_split(b,2)];halfdiff=abs(np.mean(b[:5])-np.mean(b[5:]));
 return {'integrated_autocorrelation_samples_IPS_pilot':float(tau),'effective_samples_IPS_pilot':float(len(x)/(2*tau)),'half_difference_over_combined_block_SE':float(halfdiff/np.linalg.norm(halfse)), 'mean':float(np.mean(x)),'SE_descriptive':float(b.std(ddof=1)/np.sqrt(len(b))),'blocks':b.tolist(),'first_half':float(x[:len(x)//2].mean()),'second_half':float(x[len(x)//2:].mean())}
def fluc(V,H,T):return {'kappa_bar_inverse':float(np.var(V,ddof=1)/(KB*T*np.mean(V))*PV),'alpha_K_inverse':float(np.cov(V,H,ddof=1)[0,1]/(KB*T*T*np.mean(V))),'CG_Cp_J_mol_K':float(np.var(H,ddof=1)/(N*KB*T*T)*1000+KIN*R)}
