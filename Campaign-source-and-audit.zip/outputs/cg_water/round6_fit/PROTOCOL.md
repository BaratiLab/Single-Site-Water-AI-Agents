# Round 6 joint radial–coordination–angular fit

This protocol is declared before round-6 MD. Two starting families are used: the frozen round-5 c21 model and the literature-derived accurate polynomial mW reference. Prior round-5 validation data may be used as round-6 training/initialization data; they are no longer held out. New final validation must use fresh seeds and state points.

## Explicit constraints and ranking

For each property define a normalized discrepancy, absolute error divided by its declared tolerance. Rank primarily by the maximum discrepancy, rather than a compensating weighted sum. A candidate passes the mean-value research gates only when every discrepancy is at most one. Complexity and experimental RDF residual break near ties only after this primary criterion; no good property can cancel a failed property.

Reference state298.15K, density0.997047039g/cm3, pressure1bar. Tolerances: pressure150bar; compressibility25% of4.524632587e-5/bar; expansion50% of2.57287426e-4/K; pressure-temperature derivative50% of5.6863717bar/K; ideal-vapor cohesion proxy2kJ/mol around43.98748kJ/mol; O-O peak height30% of2.57; peak position0.1Angstrom around2.80. Density0.5% is a later independent NPT gate, never imposed-density fitting success. These are declared research tolerances, not uncertainty estimates or claims of experimental-level accuracy.

Experimental structural reference: original Skinner2013 X-ray curve at295.15K, acquired before this fit and archived under round6_reference with pinned provenance. Full RDF RMSE2.4–5.8Angstrom tolerance0.15 is an additional research shape gate. Report the authors' estimated errors without treating bins as independent chi-square observations. OPC3 is descriptive only. Initial298.15K RDF comparisons have a3K offset and are screening diagnostics; final fitting includes a separate295.15K state at IAPWS density0.997772886443g/cm3.

## Model functions and identifiability

Both radial shells are fitted jointly: compact C2 first-shell amplitude/asymmetry/curvature updates, and an independent second-shell update, represented on each seed's cubic spline grid. They do not extend the radial support. The angular coefficient is the independent strictly positive quadratic L(n)=l0+l1*(n-nref)+l2*(n-nref)^2, avoiding the old linkage l1^2=4*l0*l2. Each fixed coordination center is determined from its seed, not redundantly optimized with coefficients. Embedding can use linear/quadratic response and stabilized cubic/quartic terms. Strict angular positivity, h4>=0, a repulsive core, no sampled collapse, and positive bulk modulus remain mandatory. General positive-Q angular radial weights remain those of each seed during initial joint fitting; the two families already test different weight functions and supports.

Initial proposals use exact energy/virial basis responses and canonical covariance where statistically useful. Reweighting overlap is diagnosed and never substituted for actual MD. A proposal with poor overlap is explicitly provisional. Parameter updates have trust bounds and function-family ablations, rather than an unconstrained coefficient grid.

## Sequential experiment budget

Initial budget24N64 canonical screening runs,10ps equilibration plus40ps production each,1fs,Langevin gamma5/ps. Screen observables include pressure, cohesion, experimental RDF diagnostics, canonical P_T and a many-body Born-minus-stress-fluctuation bulk modulus. Born evaluation uses uniform-scale energy second differences and is independently checked against existing N512 EOS data before ranking. Short-run block uncertainty is retained; canonical screens cannot qualify EOS properties.

Run the first8 actual models across both seed families, then pause for the upstream native LLM-SR Sampler/Evaluator/ExperienceBuffer registration. Read the returned prompt and evaluations before authoring the next adaptive batch. Continue in bounded batches to24 models, with term-family labels and immutable parameter hashes. All failures remain recorded. Screening and large-cell fitness are kept in separate stages.

Rescreen4–6 finalists using actual N512 MD: five-state EOS cross at298.15K with density0.97705/0.99705/1.01705g/cm3 and at278.15/318.15K at central density, plus the exact experimental RDF state295.15K/rho0.997772886443. Each state10ps equilibration plus30ps production. Regress pressure against measured mean temperatures. Final constraints use these EOS derivatives and exact-temperature experimental RDF, not a more favorable canonical estimator.

Freeze only after the larger-cell joint criteria have been evaluated. If no candidate passes, identify the least-violating candidate and its failed constraints explicitly; do not label it qualified. Fresh independent NPT/EOS/RDF/dynamics validation follows the final immutable hash. No friction calibration is inherited from earlier models.

## Trial schema

TRIALS.json is a chronological list. Each record includes sequence,trial_id,stage,structure_label,model_path,model_sha256,objective_value(maximum normalized discrepancy),fitness(negative objective),normalized_violations,feasible,complexity,properties,uncertainty,trajectory_path,and timestamps. The final study also records response/overlap diagnostics, exact reference provenance and engine SHA. No independent validation data feed the search buffer.

Amendment before first scored candidate batch: canonical Born screening failed its prior-training EOS comparison (68% discrepancy in compressibility). Retain it as a failed diagnostic. All first eight candidate fitness values instead use actual five-state N64 EOS, 5ps equilibration plus20ps production per state, nominal T278.15/298.15/318.15 and rho0±.02. Regress measured temperature, not thermostat target. Two exact seed controls receive identical budgets. No Born-derived property enters ranking. Pause after eight actual records for native LLMSR experience feedback.
