"""Compile local GPL-2.0-or-later CG research plugin against active LAMMPS ABI."""
from pathlib import Path
import lammps,subprocess,shutil,sys
h=Path(__file__).resolve().parent;r=Path(lammps.__file__).parent;root=h.parents[2]
cmd=[shutil.which('clang++') or shutil.which('g++'),'-O3','-std=c++17','-fPIC','-shared',f'-I{r}/include/lammps',f'-I{r.parent}/include',f'-I{root}/outputs/v5/lammps_vendor',str(h/'cg_moment.cpp'),f'-L{r}','-llammps',f'-Wl,-rpath,{r}','-o',str(h/('cg_moment.dylib' if sys.platform=='darwin' else 'cg_moment.so'))]
subprocess.run(cmd,check=True)
