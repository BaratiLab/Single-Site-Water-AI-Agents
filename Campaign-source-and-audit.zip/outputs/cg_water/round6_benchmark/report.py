from pathlib import Path
import json,csv
import numpy as np
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
H=Path(__file__).resolve().parent;O=H.parent/'round6_optimization';d=json.load(open(H/'RESULTS.json'));f=json.load(open(O/'FAST_BENCHMARK.json'))
labels={'native_mW':'Native mW','polynomial_mW':'Polynomial mW','frozen_candidate':'c34 primary','optimized_alias':'c34 cutoff alias','current_alias':'Current c34 alias','fast_alias':'Fused c34 kernel'};colors={'native_mW':'#b08758','polynomial_mW':'#547ba2','frozen_candidate':'#bf6478','optimized_alias':'#2a9a8c','current_alias':'#547ba2','fast_alias':'#2a9a8c'}
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False})
def panel(ax,data,title):
 s=data['summary'];v=np.array([r['wall_mean_seconds'] for r in s]);lo=np.array([r['wall_range_seconds'][0] for r in s]);hi=np.array([r['wall_range_seconds'][1] for r in s]);y=np.arange(len(s));ax.barh(y,v,color=[colors[r['mode']] for r in s],height=.55);ax.errorbar(v,y,xerr=np.vstack([v-lo,hi-v]),fmt='none',ecolor='#303741',capsize=4,lw=1);ax.set_yticks(y,[labels[r['mode']] for r in s]);ax.invert_yaxis();ax.set_xlim(0,max(hi)*1.18);ax.set_xlabel('Seconds / 10 ps MD (lower is cheaper)');ax.set_title(title,loc='left',weight='bold',fontsize=11)
 for i,x in enumerate(v):ax.text(hi[i]+.15,i,f'{x:.2f} s',va='center',fontsize=9)
for target,data,title in [(H/'COST_COMPARISON',d,'Four-model fixed-budget comparison'),(O/'FAST_COST_COMPARISON',f,'One bounded exact-kernel optimization')]:
 fig,ax=plt.subplots(figsize=(8.5,4.3));panel(ax,data,title);fig.text(.02,.02,'512 beads · 1 CPU thread · 1 fs · 3 ps NVT preparation + 10 ps NVE · whiskers: observed range',fontsize=8);fig.tight_layout(rect=(0,.06,1,1));fig.savefig(str(target)+'.png',dpi=220);fig.savefig(str(target)+'.svg');plt.close(fig)
fig,ax=plt.subplots(1,2,figsize=(13,4.7));panel(ax[0],d,'Four-model comparison: 4 counterbalanced repeats');panel(ax[1],f,'Exact-kernel optimization: 3 counterbalanced repeats');fig.text(.02,.06,'512 beads · Apple M2 · one CPU thread · identical 1 fs / preparation protocol · no Python timestep callbacks or trajectory I/O',fontsize=8);fig.text(.02,.015,'Fast/native timing ranges overlap: no established speed advantage over native mW. Short-budget cost only; no equal-accuracy qualification.',fontsize=8,color='#803b45');fig.tight_layout(rect=(0,.12,1,1));fig.savefig(H/'ALL_COST_COMPARISONS.png',dpi=200);fig.savefig(H/'ALL_COST_COMPARISONS.svg');plt.close(fig)
for folder,data in [(H,d),(O,f)]:
 rows=[]
 for r in data['summary']:
  rows.append({'model':r['mode'],'wall_mean_s_per_10ps':r['wall_mean_seconds'],'wall_min_s':r['wall_range_seconds'][0],'wall_max_s':r['wall_range_seconds'][1],'loop_mean_s':r['loop_mean_seconds'],'wall_ns_per_day':r['wall_ns_per_day'],'all_T_mean_within5percent':r['all_mean_temperatures_within_5percent'],'all_stability_smoke_pass':r['all_stability_smoke_pass']})
 with open(folder/('COST_TABLE.csv' if folder==H else 'FAST_COST_TABLE.csv'),'w') as stream:w=csv.DictWriter(stream,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
