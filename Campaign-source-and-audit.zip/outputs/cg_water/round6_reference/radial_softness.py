"""Untested radial-function proposal: decouple first-shell width from depth.
Offline compact coordinate warp, represented by the existing runtime cubic.
No claim of acceptable properties until actual joint MD is performed.
"""
from pathlib import Path
import copy,json
import numpy as np
from scipy.interpolate import CubicSpline

def propose(model,softness,anchor_A=2.8):
 if not 1<=softness<=1.7:raise ValueError('Outside declared proposal range')
 k=np.asarray(model['pair_knots_A']);c=np.asarray(model['pair_coefficients_descending'])
 if k[-1]<3.9:raise ValueError('Need tail beyond warp support')
 def smooth(t):
  t=np.clip(t,0,1);return t**3*(10-15*t+6*t*t)
 def evaluate(r):
  i=np.clip(np.searchsorted(k,r,side='right')-1,0,len(k)-2);z=r-k[i]
  return ((c[0,i]*z+c[1,i])*z+c[2,i])*z+c[3,i]
 B=smooth((k-2.3)/.3)*smooth((3.9-k)/.7)
 effective=k-(1-1/softness)*(k-anchor_A)*B
 values=evaluate(effective)
 z=k[-1]-k[-2];dlast=(3*c[0,-1]*z+2*c[1,-1])*z+c[2,-1]
 out=copy.deepcopy(model)
 out['pair_coefficients_descending']=CubicSpline(k,values,bc_type=((1,c[2,0]),(1,dlast))).c.tolist()
 out['radial_softness_proposal']={'softness':softness,'anchor_A':anchor_A,'formula':'r_eff=r-(1-1/softness)*(r-anchor)*B(r); B=C2smoothstep((r-2.3)/.3)*C2smoothstep((3.9-r)/.7)','representation':'Values resampled onto original cubic grid; endpoint slopes preserved. Between-knot interpolation can leak outside nominal warp support; core/tail agreement must be checked.','scope':'Untested parameterization proposal based on persistent compressibility failure; not a fitted or qualified model.'}
 return out

if __name__=='__main__':
 D=Path(__file__).resolve().parent;B=D.parent
 for trial in [16,20]:
  m=json.loads((B/f'round6_fit/candidate_{trial:02d}.json').read_text())
  ident=propose(m,1)
  error=float(np.max(abs(np.asarray(m['pair_coefficients_descending'])-np.asarray(ident['pair_coefficients_descending']))))
  assert error<1e-6,error
  for s in [1.2,1.5]:
   (D/f'softness_c{trial}_{s:.1f}.json').write_text(json.dumps(propose(m,s),indent=2))
 print('Created four UNTESTED radial-width proposals; identity coefficient check passed.')
