from pathlib import Path
import json,hashlib
D=Path(__file__).resolve().parent;F=D.parent/'round6_fit'
raw=(F/'TRIALS.json').read_bytes();records=json.loads(raw)
assert records and records[0]['sequence']==0
(D/'TRIALS_SNAPSHOT.json').write_bytes(raw)
proposals=[]
for r in records:
 if r['sequence']==0:continue
 p=Path(r['model_path'])
 if not p.exists():p=F/p.name
 assert hashlib.sha256(p.read_bytes()).hexdigest()==r['model_sha256']
 m=json.loads(p.read_text());e=m.get('embedding',{});u=m.get('undercoordination',{})
 terms=['refitted_radial_cubic(r)','K2*delta_n**2+K1*delta_n',f'n=sum(max(0,1-r**2/{e.get("rd",5)}**2)**3)']
 if m.get('radial_softness_proposal'):terms.append('offline_compact_coordinate_warp_then_runtime_cubic')
 if m.get('radial_IBI_proposal'):terms.append('regularized_RDF_feedback_then_runtime_cubic')
 for key,power in [('h3',3),('h4',4)]:
  if e.get(key,0):terms.append(f'{key}*delta_n**{power}')
 for key,power in [('A3',3),('A4',4)]:
  if u.get(key,0):terms.append(f'{key}*max(0,1-n/nstar)**{power}')
 terms.append('(l0+l1*delta_n+l2*delta_n**2)*A' if m.get('angular_polynomial') else 'legacy_lambda*(1+b*delta_n)**2*A')
 degree=len(m.get('angular_weight',{}).get('coefficients_ascending',[1]))-1
 terms.append(f'w=s**3*Q_degree_{degree}(s)**2')
 proposals.append({'sequence':r['sequence'],'label':r['structure_label'],'terms':terms,'coordination_cutoff_A':e.get('rd',5),'undercoordination_threshold':u.get('nstar',1),'trial_id':r['trial_id'],'stage':r['stage'],'model_sha256':r['model_sha256']})
(D/'proposals.json').write_text(json.dumps(proposals,indent=2))
(D/'SNAPSHOT_MANIFEST.json').write_text(json.dumps({'records':len(records),'sha256':hashlib.sha256(raw).hexdigest(),'scope':'Training-only chronological feedback; frozen holdout excluded.'},indent=2))
