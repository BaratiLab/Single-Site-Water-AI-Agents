"""ActualstockLAMMPSmW,orthogonalserialrealunits; no researchplugin."""
import os
os.environ.setdefault('OMP_NUM_THREADS','1')
import json
from pathlib import Path
import numpy as np
from lammps import lammps
H=Path(__file__).resolve().parent

def export(model,path):
 m=json.load(open(model)) if isinstance(model,(str,Path)) else model
 import hashlib
 raw=(H/m['parameter_file']).read_bytes();assert hashlib.sha256(raw).hexdigest()==m['parameter_sha256'];Path(path).write_bytes(raw);return m

def write_data(path,x,box):
 box=np.broadcast_to(box,(3,));x=np.asarray(x)%box
 s=['CG coordinates','',f'{len(x)} atoms','1 atom types','']+[f'0 {v:.17g} {a}lo {a}hi' for a,v in zip('xyz',box)]+['','Masses','','1 18.01528','','Atoms # atomic','']+[f'{i+1} 1 '+' '.join(map(str,v)) for i,v in enumerate(x)]
 Path(path).write_text('\n'.join(s)+'\n')

def create(model,x,box,prefix):
 prefix=Path(prefix);prefix.parent.mkdir(parents=True,exist_ok=True);export(model,prefix.with_suffix('.params'));write_data(prefix.with_suffix('.data'),x,box)
 l=lammps(cmdargs=['-screen','none','-log',str(prefix.with_suffix('.log'))]);l.commands_list(['units real','atom_style atomic','boundary p p p','atom_modify map array sort 0 0',f'read_data {prefix.with_suffix(".data")}','pair_style sw',f'pair_coeff * * {prefix.with_suffix(".params")} MW','neighbor 1 bin','neigh_modify every 1 delay 0 check yes','thermo_style custom step temp pe ke etotal press vol','thermo 1000']);return l

def run(model,x,box,prefix,T=298.15,steps=20000,equil=5000,sample=100,dt_fs=1.,gamma_ps=5.,seed=83401,ensemble='nvt',pressure_bar=1.,tdamp_fs=100.,pdamp_fs=1000.):
 l=create(model,x,box,prefix);l.commands_list([f'timestep {dt_fs}',f'velocity all create {T} {seed} mom yes rot no dist gaussian'])
 if ensemble=='nvt':l.commands_list(['fix int all nve',f'fix bath all langevin {T} {T} {1000/gamma_ps} {seed+13} zero yes'])
 elif ensemble=='npt':l.command(f'fix int all npt temp {T} {T} {tdamp_fs} iso {pressure_bar/1.01325} {pressure_bar/1.01325} {pdamp_fs}')
 elif ensemble=='nve':l.command('fix int all nve')
 else:raise ValueError(ensemble)
 l.command(f'run {equil}');out={k:[] for k in ['time_ps','temperature_K','pressure_bar','potential_kJ_mol','total_kJ_mol','volume_A3','positions_A','cell_A']}
 for j in range(steps//sample):
  l.command(f'run {sample} pre no post no');lo,hi,*_=l.extract_box();b=np.asarray(hi)-lo
  vals=[l.get_thermo('time')*.001,l.get_thermo('temp'),l.get_thermo('press')*1.01325,l.get_thermo('pe')*4.184,l.get_thermo('etotal')*4.184,l.get_thermo('vol'),np.asarray(l.gather_atoms('x',1,3)).reshape(-1,3).copy(),b]
  for k,v in zip(out,vals):out[k].append(v)
 l.close();out={k:np.asarray(v) for k,v in out.items()};out['density_g_cm3']=len(x)*18.01528/6.02214076e23/(out['volume_A3']*1e-24);np.savez_compressed(str(prefix)+'.npz',**out);return out

def isolated_energy_kJ_mol(model):
 """Consistent zero-neighbor bead reference; angular invariant is zero."""
 m=json.load(open(model)) if isinstance(model,(str,Path)) else model
 e=m.get('embedding',{});u=m.get('undercoordination',{})
 n0=e.get('n0',0)
 return e.get('K2',0)*n0*n0-e.get('K1',0)*n0+u.get('A3',0)+u.get('A4',0)
