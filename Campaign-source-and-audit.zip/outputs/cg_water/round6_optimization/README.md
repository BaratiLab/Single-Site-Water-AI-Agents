# Completed exact representation and bounded kernel optimization

Primary c34 is unchanged: SHA b465820825ebda1337ac11ada2ac3942e1ed5ab287aed7c439a6d7cc3c29070c. There was no potential refitting in this directory.

## Exact zero-tail alias

optimized_alias.json has SHA8b8c18324246b64b0d9e147d2ec383f5d6240a9868c9ea0aef7030e184d4eb35. Neighbor cutoff decreased6→5.5Angstrom. True radial support is4.306500000000001Angstrom, angular support4.3065 and coordination support5.5. Every removed interval has exactly zero cubic coefficients. Removed edges have zero radial energy/force, angular weight/derivative and coordination weight/derivative.

EQUIVALENCE_REPORT.json records20 training frames with EXACTLY ZERO energy, force and all-six-virial errors. A2ps1fs NVE smoke passed. The primary JSON, native source/binary and native.py remain unchanged. This is exact representation optimization, not a new water fit.

## One bounded fast-kernel attempt

fast_kernel/cg_moment_fast.cpp and its separately built cg_joint_fast.dylib register cg/joint/fast. They fuse coordination-density accumulation into the first neighbor pass and skip radial interval search outside the last strictly nonzero radial support. No full-force fusion or repeated optimization campaign was attempted.

The first implementation reassociated the angular distance dot product and narrowly failed the1e-8 virial parity gate (maximum1.89e-8kJ/mol); FAST_INITIAL_PARITY_FAILED.json retains that result. Restoring the original angular distance evaluation order removed this roundoff difference. FAST_QUALIFICATION.json then records20-frame EXACT ZERO energy/force/all-six-virial differences and a successful2ps1fs NVE smoke. Qualification applies to this frozen model, not arbitrary future parameters.

The separate exclusive three-model block used three counterbalanced repeats, the same512bead/1fs protocol and3ps NVT +10ps NVE budget. All9 stability and mean-temperature-within5% flags passed.

| Model | Mean seconds /10ps | Observed range |
|---|---:|---:|
| Native mW |7.586|7.408–7.793|
| Current c34 alias |9.065|8.775–9.608|
| Fused c34 kernel |8.292|6.810–10.167|

The fused mean is8.53% less costly than the current alias but9.30% more costly than native mW. Ranges overlap substantially and scheduling variability is large: **no speed advantage over native mW is established**. No extra repeats were selected after the required three. Do not chain percentage reductions across this and the earlier four-model block as an independent production benchmark.

FAST_BENCHMARK.json contains all rows, summaries, scope, hardware, threads and primary/alias/source/binary hashes. FAST_COST_TABLE.csv and FAST_COST_COMPARISON.png expose observed ranges. No equal-accuracy, real-water time mapping, equilibrium or production-performance qualification is claimed.

## Reproduction

Build the separate fast artifact (never overwrite the live library):

```
PYTHONPATH=work/lammps_runtime python outputs/cg_water/round6_optimization/fast_kernel/build.py
PYTHONPATH=work/lammps_runtime OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 python outputs/cg_water/round6_optimization/qualify_fast.py
```

The qualification script's original20-frame training trajectory is needed; that large trajectory is identified by hashes rather than included in the compact archive. A single snapshot suffices for basic mechanics but cannot recreate a20-frame claim.

After qualification and only while other MD/analysis is idle:

```
PYTHONPATH=work/lammps_runtime OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 python outputs/cg_water/round6_optimization/benchmark_fast.py --candidate outputs/cg_water/round6_engine/frozen_model.json --candidate-sha256 b465820825ebda1337ac11ada2ac3942e1ed5ab287aed7c439a6d7cc3c29070c --polynomial-mw outputs/cg_water/round6_optimization/optimized_alias.json --initial-trajectory outputs/cg_water/round6_benchmark/benchmark_initial_snapshot.npz --exclusive-go
```

--polynomial-mw is a retained argument name in this separate harness; here it explicitly selects the current c34 alias for both original/fast kernels. The implementation and CLI are stored alongside the measurements. COMMON_INITIAL_GEOMETRY_PARITY.json verifies byte-identical common512.data across both timing blocks.
