from pathlib import Path
import json,hashlib,sys,csv,shutil
D=Path(__file__).resolve().parent
rows=[json.loads(p.read_text()) for p in D.glob('N512_TRIAL_*.json')]
assert len(rows)>=int(sys.argv[1]),'Training refinements still pending'
rows.sort(key=lambda r:(r['objective_value'],r['complexity']['pair_intervals']))
strict_winner=rows[0];winner=next(r for r in rows if r['trial_id'].endswith('_c'+sys.argv[2])) if len(sys.argv)>2 else strict_winner;src=Path(winner['model_path']);out=D/'selected_candidate.json';shutil.copyfile(src,out);sha=hashlib.sha256(out.read_bytes()).hexdigest();assert sha==winner['model_sha256'];m=json.loads(out.read_text())
manifest={'state':'FROZEN_FOR_FRESH_INDEPENDENT_VALIDATION','qualified_model':False,'independent_density_gate_not_evaluated':True,'all_fitted_training_gates_passed':winner['feasible'],'selection_rule':'PRE-HOLDOUT amendment selects c34 among two same-budget mean-feasible near-tied models for lower EOS-predicted density risk; original strict minmax winner c33 preserved. See SELECTION_AMENDMENT.json. No heldout selection.','strict_original_minimax_winner':strict_winner['trial_id'],'selection_amendment_path':str((D/'SELECTION_AMENDMENT.json').resolve()),'winner':winner['trial_id'],'model_path':str(out.resolve()),'model_sha256':sha,'engine_path':str((D.parent/'round6_engine/native.py').resolve()),'training_candidates':[{'trial_id':r['trial_id'],'objective':r['objective_value'],'hash':r['model_sha256'],'feasible':r['feasible']} for r in rows],'current_fit_provenance':'Round6 joint radial/generalL/embedding/coordination function trials with actualnativeLLM-SRfeedback.32actualN64screens; alllegacyround5metadata insidefrozenJSONishistory,notcurrentvalidationclaims.','historical_metadata_policy':'FrozenJSONpreservedbyteexact; inheritedsource/calibration_round3/angularinitializationfieldsdonotdescribecurrentfit. Thismanifest+TRIALS+REPORTprovidecurrentprovenance.','independent_validation_status':'Notusedforselection; mustbefreshseedsandmechanicscheckedbeforeproduction.'};(D/'FREEZE.json').write_text(json.dumps(manifest,indent=2));(D/'TRAINING_SELECTION.json').write_text(json.dumps({'winner':winner,'strict_minimax_winner':strict_winner,'selection_amendment':json.loads((D/'SELECTION_AMENDMENT.json').read_text()),'all_largecell_trials':rows},indent=2))
shutil.copyfile(Path(strict_winner['model_path']),D/'strict_minimax_candidate.json')
with (D/'selected_radial_coefficients.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['r_left_A','r_right_A','cubic_kJmol_A3','quadratic_kJmol_A2','linear_kJmol_A','constant_kJmol']);co=m['pair_coefficients_descending']
 for i in range(len(m['pair_knots_A'])-1):w.writerow([m['pair_knots_A'][i],m['pair_knots_A'][i+1],*[c[i] for c in co]])
p=D/'REPORT.md';s=p.read_text();s+='\n## Frozen training selection\n\nPrimaryc34waschosenbyanexplicitPRE-HOLDOUTdensity-riskamendment; strictoriginalminimaxwinnerc33ispreservedascomparator. Thisisnotretrospectiveheldoutselection. SeeSELECTION_AMENDMENT.json.\n\n';s+='|Candidate|Worst normalized error|Pressure bar|kappa 1/bar|alpha 1/K|P_T bar/K|Cohesion proxy kJ/mol|RDF RMSE295K|\n|---|---:|---:|---:|---:|---:|---:|---:|\n'
for r in rows:
 a=r['properties'];s+=f"|{r['trial_id']}|{r['objective_value']:.4f}|{a['pressure_bar']:.2f}|{a['kappa_bar_inverse']:.7g}|{a['alpha_K_inverse']:.7g}|{a['P_T_bar_K']:.3f}|{a['cohesion_proxy_kJ_mol']:.3f}|{a['experimental_RDF_RMSE']:.4f}|\n"
s+='\nThe imposed NVT density is not validation. Linear-EOS predicted equilibrium densities (with block-bootstrap diagnostic intervals) are:\n'
for r in rows:s+=f"\n- {r['trial_id']}: {r.get('EOS_root_density_g_cm3',float('nan')):.6f} g/cm³, relative error {100*r.get('EOS_root_density_relative_error',float('nan')):+.3f}%, diagnostic95% {r.get('EOS_root_density_block_bootstrap_95')}; central-anchored density {r.get('central_anchored_EOS_root_density_g_cm3',float('nan')):.6f}, diagnostic95% {r.get('central_anchored_EOS_root_density_block_bootstrap_95')}. These are predictions, not NPT qualification.\n"
s+=f"\nFrozen winner: {winner['trial_id']}; SHA256 `{sha}`. Research gates passed: {winner['feasible']}. This is a training selection, not independently validated accuracy.\n";p.write_text(s)
(D/'SYMBOLIC_MODEL.md').write_text('''# Frozen symbolic potential

U = sum_(i<j) phi(rij) + sum_i [K1*d_i + K2*d_i² + h3*d_i³ + h4*d_i⁴ + A3*s_i³ + A4*s_i⁴ + L(n_i)*A_i].

d_i=n_i−n0; n_i=sum_j max(0,1−rij²/rd²)³; s_i=max(0,1−n_i/nstar).
L(n)=l0+l1*(n−nref)+l2*(n−nref)² when angular_polynomial exists; otherwise inherited square fallback.
Angular w(r)=t³ Q(t)², t=max(0,1−r²/rc²), Q(t)=sum_k q_k*t^k.
A_i=sum_(j<k) w(rij)*w(rik)*(cos(theta_jik)+1/3)².
The engine evaluates this invariant with vector and tensor moments, not explicit neighbor-triplet enumeration.
phi(r)=c3_j*(r−a_j)³+c2_j*(r−a_j)²+c1_j*(r−a_j)+c0_j on each interval [a_j,a_(j+1)); exact coefficients in selected_radial_coefficients.csv. Below first knot, phi=phi(a0)+phi'(a0)*(r−a0)+10000*(r−a0)^4; above final knot, zero.

All coefficients below are exact frozen JSON values; energies kJ/mol, distances Angstrom, dimensionless coordination. These are per-bead many-body functions, not water charges or a dielectric model.

```json
'''+json.dumps({k:m[k] for k in ['embedding','undercoordination','angular_polynomial','angular_cutoff_A','angular_weight'] if k in m},indent=2)+'\n```\n')
print(json.dumps(manifest,indent=2))
