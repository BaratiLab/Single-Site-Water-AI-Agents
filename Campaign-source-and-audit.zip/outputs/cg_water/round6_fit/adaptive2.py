from batch1 import *
sys.path.insert(0,str(B/'round6_reference'));from radial_ibi import propose
PROMPT=B/'round6_llmsr/native_batch1/next_prompt.txt'
configs=[(3,-5,0,1,None,1),(3,-10,0,2,None,1),(7,-6,0,1,None,1),(7,-10,0,2,None,1),(3,-6,0,1,(75,15),1),(3,-6,-1,2,None,1),(3,-8,0,2,None,1.3),(3,-6,0,1,None,.8)]
def prepare2():
 specs=json.loads((D/'BATCH1_SPECS.json').read_text())
 for q,(source,K2,h3,h4,coupling,scale) in enumerate(configs,8):
  src=D/f'candidate_{source:02d}.json';m=json.loads(src.read_text());e=m['embedding'];e.update(K2=K2,h3=h3,h4=h4);m['undercoordination']['nstar']=e['n0'];a=m['angular_polynomial'];a['l0']*=scale
  if coupling:a.update(l1=coupling[0],l2=coupling[1])
  z=np.load(D/f'RDF_{source:02d}.npz');rp=D/f'IBI_reference_{source:02d}.npz';np.savez(rp,r_A=z['r_A'],g=z['g'],experimental_shell_average=z['target']);m=propose(m,rp,relaxation=.3)
  z=np.load(D/f'q{source:02d}_s0/trajectory.npz');frames=z['positions_A'][-4:];L=float(z['cell_A'][0,0]);eps=1e-4
  def metrics(mm):
   en=[];pp=[]
   for x in frames:
    E=energy(mm,x,L)[0];u=(energy(mm,x,L,np.exp(eps))[0]-energy(mm,x,L,np.exp(-eps))[0])/(2*eps);en.append(E/64);pp.append(-u/(3*L**3)*16605.39067+63*kb*298.15/L**3*16605.39067)
   return np.array([np.mean(pp),isolated(mm)-np.mean(en)+kb*298.15])
  history=[]
  for iteration in range(2):
   base=metrics(m);mk=copy.deepcopy(m);mk['embedding']['K1']+=1;mr=copy.deepcopy(m);radial(mr,1,0,0);J=np.column_stack((metrics(mk)-base,metrics(mr)-base));delta=np.clip(np.linalg.lstsq(J,np.array([1,43.98748])-base,rcond=None)[0],[-2,-1.5],[2,1.5]);m['embedding']['K1']+=float(delta[0]);radial(m,float(delta[1]),0,0);history.append({'before':base.tolist(),'delta_K1_firstwell':delta.tolist(),'predicted_after':(base+J@delta).tolist()})
  m['round6_adaptive_provenance']={'parent':str(src),'parent_hash':hashlib.sha256(src.read_bytes()).hexdigest(),'feedback_prompt':str(PROMPT),'feedback_prompt_sha256':hashlib.sha256(PROMPT.read_bytes()).hexdigest(),'matching_frame_source':str(D/f'q{source:02d}_s0/trajectory.npz'),'static_counterterm_iterations':history,'proposal_rationale':'Measured softening response c03 and reduced PT c07 combined; radial IBI corrects measured first/second-shell shape. Static response requires actual relaxation validation.'};p=D/f'candidate_{q:02d}.json';p.write_text(json.dumps(m,indent=2));specs.append({'q':q,'seed_family':1,'structure_label':f'feedback_joint_softK{K2}_h3{h3}_h4{h4}_Lscale{scale}_positiveL{a["l1"]}_IBI03','path':str(p)})
 (D/'BATCH1_SPECS.json').write_text(json.dumps(specs,indent=2))
if __name__=='__main__':
 if sys.argv[1]=='prepare':prepare2()
 else:
  for q in range(8+int(sys.argv[1]),16,2):evaluate(q)
