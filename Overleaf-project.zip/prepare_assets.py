from pathlib import Path
import json,shutil,hashlib
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch,FancyArrowPatch
D=Path(__file__).resolve().parent;B=D.parent/'cg_water'
for n in ['figures','model','evidence','lammps']: (D/n).mkdir(exist_ok=True)
for src,dst in [('round6_fit/TRAINING_PROGRESS.pdf','figures/training.pdf'),('round6_validation/INDEPENDENT_COMPARISON.pdf','figures/validation.pdf'),('round6_benchmark/ALL_COST_COMPARISONS.png','figures/cost.png'),('round6_fit/selected_candidate.json','model/frozen_c34.json'),('round6_fit/selected_radial_coefficients.csv','model/radial_coefficients.csv')]:shutil.copyfile(B/src,D/dst)
for folder,names in {'round6_validation':['COMPARISON.json','PROPERTY_COMPARISON.csv','GATES.json','RESPONSE_QUALIFICATION.json','EOS_MODEL_DIAGNOSTICS.json','CURVATURE_INTERPRETATION.json','PREDECLARED_PROTOCOL.json','INPUT_PROVENANCE.json'],'round6_fit':['FREEZE.json','TRAINING_SELECTION.json','TRIALS.json','RUN_BUDGET.json','SELECTION_AMENDMENT.json','IDENTITY_HASH_AUDIT.json'],'round6_reference':['SOURCE.json','README.txt'],'round6_benchmark':['RESULTS.json','COST_TABLE.csv','benchmark_initial_snapshot.npz'],'round6_optimization':['FAST_BENCHMARK.json','FAST_QUALIFICATION.json','EQUIVALENCE_REPORT.json','optimized_alias.json'],'round6_llmsr':['README.txt']}.items():
 dest=D/'evidence'/folder;dest.mkdir(exist_ok=True)
 for name in names:shutil.copyfile(B/folder/name,dest/name)
shutil.copyfile(B/'round6_llmsr/native_final/manifest.json',D/'evidence/LLMSR_FINAL_MANIFEST.json')
for name in ['cg_moment.cpp','native.py','build_portable.py','lammpsplugin.h','LICENSE-LAMMPS','REPRODUCE.txt','FROZEN_RELEASE.json','frozen_model.params','frozen_start512.data','example_nvt.in.template','REPRODUCIBILITY_SMOKE.json','FINALIST_MECHANICS_ADJUDICATION.json']:
 shutil.copyfile(B/'round6_engine'/name,D/'lammps'/name)
shutil.copyfile(D.parent/'water_swarm_paper/references.bib',D/'references.bib')
with (D/'references.bib').open('a') as f:f.write('\n@misc{iapws95,author={{International Association for the Properties of Water and Steam}},title={Revised Release on the IAPWS Formulation 1995 for the Thermodynamic Properties of Ordinary Water Substance for General and Scientific Use},year={2018},howpublished={R6-95(2018)},url={https://iapws.org/technical-guidance/release/IAPWS-95}}\n')
fig,ax=plt.subplots(figsize=(12,4.7));fig.patch.set_facecolor('white');ax.set(xlim=(0,12),ylim=(0,4.7));ax.axis('off')
def box(x,y,w,h,title,body,color):
 ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.12,rounding_size=.12',edgecolor=color,facecolor=color+'12',linewidth=1.5))
 ax.text(x+w/2,y+h-.26,title,ha='center',va='center',fontsize=(12 if len(title)>20 else 13),fontweight='bold',color=color)
 ax.text(x+w/2,y+h/2-.18,body,ha='center',va='center',fontsize=12,color='#243448',linespacing=1.5)
def arrow(a,b,c='#72869a'):ax.add_patch(FancyArrowPatch(a,b,arrowstyle='-|>',mutation_scale=13,color=c,linewidth=1.5))
box(4.25,3.45,3.5,.9,'COORDINATOR','Scope, constraints, freeze, audit','#243b67')
roles=[(.25,'FITTING SPECIALIST','Invariant term proposals\nMeasured multi-property MD\nLLM-SR feedback buffer','#157783'),(4.3,'ENGINE SPECIALIST','Analytic energy / force / virial\nNumerical mechanics checks\nExact cost optimization','#826226'),(8.35,'VALIDATION SPECIALIST','Reserved seeds and fixed model\nNPT + EOS + matched RDF\nUncertainty and consistency','#75527e')]
for x,title,body,col in roles:box(x,1.65,3.4,1.25,title,body,col);arrow((6,3.35),(x+1.7,3.0))
box(.45,.18,7.0,.85,'TRAINING TO FREEZE','35 parameter sets  |  40 records  |  7.04 ns training','#157783')
box(8.1,.18,3.4,.85,'INDEPENDENT ASSESSMENT','600 ps fresh MD; report failures','#9a4351')
arrow((1.95,1.54),(1.95,1.1));arrow((6,1.54),(6,1.1));arrow((10.05,1.54),(10.05,1.1));arrow((7.55,.6),(7.98,.6),'#9a4351')
ax.text(6,4.57,'Four collaborating contexts; numerical tools are not additional reasoning agents',ha='center',fontsize=12,color='#243448')
fig.savefig(D/'figures/workflow.pdf',bbox_inches='tight');fig.savefig(D/'figures/workflow.png',dpi=180,bbox_inches='tight');plt.close(fig)
m=json.loads((D/'model/frozen_c34.json').read_text());k=m['pair_knots_A'];c=m['pair_coefficients_descending']
rows=['\\begin{longtable}{rrrrrr}','\\caption{Pair cubic coefficients, printed to twelve significant digits. Full floating-point precision is retained in the accompanying JSON and CSV.}\\\\','\\toprule $a_j$ & $a_{j+1}$ & $c_3$ & $c_2$ & $c_1$ & $c_0$\\\\ \\midrule \\endfirsthead','\\toprule $a_j$ & $a_{j+1}$ & $c_3$ & $c_2$ & $c_1$ & $c_0$\\\\ \\midrule \\endhead']
for j in range(len(k)-1):rows.append(' & '.join(f'{v:.12g}' for v in [k[j],k[j+1],*[c[i][j] for i in range(4)]])+r' \\')
rows+=['\\bottomrule','\\end{longtable}'];(D/'radial_table.tex').write_text('\n'.join(rows))
q=m['angular_weight']['coefficients_ascending'];(D/'angular_table.tex').write_text('\\begin{tabular}{rr}\\toprule $k$ & $q_k$\\\\\\midrule\n'+'\n'.join(f'{j} & {v!r}'+r' \\' for j,v in enumerate(q))+'\n\\bottomrule\\end{tabular}\n')
manifest={'model_SHA256':hashlib.sha256((D/'model/frozen_c34.json').read_bytes()).hexdigest(),'scope':'Compact manuscript evidence and reproduction materials; no raw trajectories or runtime-specific binaries; inherited model metadata is historical, FREEZE provides current provenance.','files':[]}
for p in sorted(D.rglob('*')):
 if p.is_file() and p.name!='ASSET_MANIFEST.json':manifest['files'].append({'path':str(p.relative_to(D)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(D/'ASSET_MANIFEST.json').write_text(json.dumps(manifest,indent=2))
