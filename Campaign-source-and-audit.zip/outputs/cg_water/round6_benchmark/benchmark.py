"""Prepared fixed-budget MD timing. Run only after explicit root GO and CPU idle."""
import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
import argparse,json,re,time,hashlib,platform,subprocess
from pathlib import Path
import numpy as np
from lammps import lammps,LMP_STYLE_GLOBAL,LMP_TYPE_ARRAY,LMP_SIZE_ROWS
H=Path(__file__).resolve().parent;B=H.parent
import sys
sys.path.insert(0,str(B/'round6_engine'));from native import write_data,export
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()

def main():
 p=argparse.ArgumentParser();p.add_argument('--candidate',type=Path,required=True);p.add_argument('--candidate-sha256',required=True);p.add_argument('--polynomial-mw',type=Path,default=B/'round5_mw_poly/candidate.json');p.add_argument('--initial-trajectory',type=Path,default=B/'round5_fit/adaptiveN512_c21_s0/trajectory.npz');p.add_argument('--optimized-alias',type=Path);p.add_argument('--equivalence-report',type=Path);p.add_argument('--exclusive-go',action='store_true',help='Use only after explicit root GO/all other MD idle');a=p.parse_args()
 if not a.exclusive_go:raise RuntimeError('Explicit exclusive CPU release is required; no benchmark started')
 if sha(a.candidate)!=a.candidate_sha256:raise RuntimeError('Candidate freeze SHA mismatch')
 z=np.load(a.initial_trajectory);x=z['positions_A'][-1].copy();old=z['cell_A'][-1] if 'cell_A' in z else z['box_A'];old=np.diag(old) if np.asarray(old).shape==(3,3) else np.broadcast_to(old,(3,));N=len(x)
 if N!=512:raise ValueError('Controlled protocol requires512beads')
 alias_qualified=False
 if a.optimized_alias and a.equivalence_report:
  eq=json.load(open(a.equivalence_report));alias_qualified=bool(eq.get('status')=='passed' and eq.get('primary_sha256')==a.candidate_sha256 and eq.get('optimized_alias_sha256')==sha(a.optimized_alias))
  if not alias_qualified:print('Alias not qualified: fall back to three-model benchmark',flush=True)
 rho=.99705;L=(N*18.01528/.602214076/rho)**(1/3);box=np.array([L,L,L]);x=x/old*box;data=H/'common512.data';write_data(data,x,box);export(a.candidate,H/'candidate.params');export(a.polynomial_mw,H/'polynomial_mw.params')
 if alias_qualified:export(a.optimized_alias,H/'optimized_alias.params')
 plugin=B/'round6_engine/cg_moment.dylib';rows=[];version=None;library=None
 def minpair(y):
  d=y[:,None,:]-y[None,:,:];d-=box*np.rint(d/box);r=np.linalg.norm(d,axis=2);np.fill_diagonal(r,np.inf);return float(r.min())
 initial_min=minpair(x)
 modes=['native_mW','polynomial_mW','frozen_candidate']+(['optimized_alias'] if alias_qualified else []);orders=[modes[j:]+modes[:j] for j in range(len(modes))]
 for replicate,order in enumerate(orders):
  seed=927119+101*replicate
  for mode in order:
   prefix=H/f'{mode}_rep{replicate}';log=prefix.with_suffix('.log');l=lammps(cmdargs=['-screen','none','-log',str(log)]);version=l.version();library=l.lib._name
   cmds=['units real','atom_style atomic','boundary p p p','atom_modify map array sort 0 0',f'read_data {data}']
   if mode=='native_mW':cmds+=['pair_style sw',f'pair_coeff * * {H}/mW.sw MW']
   else:cmds += [f'plugin load {plugin}','pair_style cg/joint',f'pair_coeff * * {H}/'+({'polynomial_mW':'polynomial_mw.params','frozen_candidate':'candidate.params','optimized_alias':'optimized_alias.params'}[mode])]
   cmds += ['neighbor 1 bin','neigh_modify every 1 delay 0 check yes','timestep 1',f'velocity all create 298.15 {seed} mom yes rot no dist gaussian','fix integration all nvt temp 298.15 298.15 100','thermo_style custom step temp pe ke etotal press','thermo_modify norm no','thermo 10000','timer full','run 3000','unfix integration','fix integration all nve','reset_timestep 0','run 0']
   l.commands_list(cmds);initial_E=l.get_thermo('etotal')*4.184;startT=l.get_thermo('temp');warmx=np.array(l.gather_atoms('x',1,3)).reshape(N,3).copy();warm_min=minpair(warmx)
   if not np.isfinite(initial_E) or not 100<startT<700 or warm_min<=1.5:
    l.close();(H/'WARMUP_FAILURE.json').write_text(json.dumps({'mode':mode,'replicate':replicate,'T_K':startT,'min_pair_A':warm_min,'message':'SharedinitialgeometryfailedshortNVEwarmup; noqualifiedcostcomparison.'},indent=2));raise RuntimeError('Warmupstabilitygatefailed')
   l.commands_list([f'variable absdrift equal abs(etotal-({initial_E/4.184:.17g}))', 'fix statistics all vector 100 c_thermo_temp v_absdrift'])
   # Single uninterrupted timed LAMMPS run: no Python callbacks or trajectory I/O.
   # Tiny identical native scalar diagnostics every100steps are included in cost.
   wall0=time.perf_counter();l.command('run 10000');wall=time.perf_counter()-wall0
   endT=l.get_thermo('temp');endE=l.get_thermo('etotal')*4.184;endP=l.get_thermo('press')*1.01325;nrow=l.extract_fix('statistics',LMP_STYLE_GLOBAL,LMP_SIZE_ROWS);samples=np.array([[l.extract_fix('statistics',LMP_STYLE_GLOBAL,LMP_TYPE_ARRAY,i,j) for j in range(2)] for i in range(nrow)]);endx=np.array(l.gather_atoms('x',1,3)).reshape(N,3).copy();l.close()
   loops=re.findall(r'Loop time of ([\d.eE+-]+).*?for (\d+) steps',log.read_text());timed=[float(s) for s,n in loops if int(n)==10000];assert len(timed)==1,loops;loop=timed[0];final_min=minpair(endx);finite=bool(np.isfinite(endx).all() and np.isfinite(samples).all());stability=bool(finite and final_min>1.5 and np.max(samples[:,1])*4.184/N<.05 and samples[:,0].min()>100 and samples[:,0].max()<700)
   r={'mode':mode,'replicate':replicate,'order_in_replicate':order.index(mode),'seed':seed,'warmup_ps':3.,'warmup_ensemble':'NVT298.15K Tdamp100fs','timed_ensemble':'NVE','timed_ps':10.,'dt_fs':1.,'N':N,'imposed_density_g_cm3':rho,'wall_seconds':wall,'LAMMPS_loop_seconds':loop,'wall_ns_per_day':.01/wall*86400,'loop_ns_per_day':.01/loop*86400,'T_start_K':startT,'T_end_K':endT,'T_sampled_mean_K':float(samples[:,0].mean()),'mean_temperature_within_5percent_of_298p15':bool(abs(samples[:,0].mean()/298.15-1)<=.05),'T_sampled_range_K':[float(samples[:,0].min()),float(samples[:,0].max())],'end_P_bar':endP,'energy_endminusstart_kJ_mol_bead':(endE-initial_E)/N,'max_sampled_energy_drift_kJ_mol_bead':float(samples[:,1].max()*4.184/N),'initial_min_pair_A':initial_min,'warmup_final_min_pair_A':warm_min,'final_min_pair_A':final_min,'stability_smoke_pass':stability,'diagnostic_samples':len(samples)};rows.append(r);print(json.dumps(r),flush=True)
   (H/'PROGRESS.json').write_text(json.dumps({'rows':rows},indent=2))
 summary=[]
 for mode in modes:
  rr=[r for r in rows if r['mode']==mode];t=np.array([r['wall_seconds'] for r in rr]);ll=np.array([r['LAMMPS_loop_seconds'] for r in rr]);summary.append({'mode':mode,'wall_mean_seconds':float(t.mean()),'wall_range_seconds':[float(t.min()),float(t.max())],'loop_mean_seconds':float(ll.mean()),'wall_ns_per_day':float(.01/t.mean()*86400),'loop_ns_per_day':float(.01/ll.mean()*86400),'all_stability_smoke_pass':all(r['stability_smoke_pass'] for r in rr),'all_mean_temperatures_within_5percent':all(r['mean_temperature_within_5percent_of_298p15'] for r in rr)})
 native=summary[0]['wall_mean_seconds']
 primary=next(r['wall_mean_seconds'] for r in summary if r['mode']=='frozen_candidate')
 for r in summary:
  r['wall_cost_relative_native_mW']=r['wall_mean_seconds']/native;r['wall_cost_relative_primary']=r['wall_mean_seconds']/primary
 try:cpu=subprocess.check_output(['sysctl','-n','machdep.cpu.brand_string'],text=True).strip()
 except Exception:cpu=platform.processor()
 files=[a.candidate,a.polynomial_mw,a.initial_trajectory,data,H/'mW.sw',B/'round6_engine/cg_moment.cpp',plugin]
 if library and Path(library).exists():files.append(Path(library))
 if alias_qualified:files.extend([a.optimized_alias,a.equivalence_report])
 report={'rows':rows,'summary':summary,'replicates_per_model':len(modes),'optimized_alias_qualified':alias_qualified,'protocol':'512beads, commoninitialgeometryandmatchedvelocityseedperreplicate; rho.99705,initialT298.15,dt1fs,NVT298.15K3pswarmup(Tdamp100fs)thenfullsetupNVE10pstimedpermodel,onecounterbalancedLatinrotationpermodel. NoPythoncallbackortrajectoryIOintimedrun; identicalnativeT/energy-driftdiagnostics every100stepsincluded. Thermo/logstart/endandtiminformationonly.','scope':'CurrentimplementationMDcostatfixedshortbudget. Notaccuracy-equivalent, experimentaltransport-clock, equilibriumorproductionqualification. TemperaturecanvarybyHamiltonian;actualTsreportedand5percentmeanTqualificationflagged.','LAMMPS_version':version,'hardware':{'platform':platform.platform(),'machine':platform.machine(),'cpu':cpu,'logical_cpu_count':os.cpu_count()},'threads':{k:os.environ[k] for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']},'sha256':{str(f):sha(f) for f in files},'candidate_sha256':sha(a.candidate),'all_other_MD_idle_required':True,'statistical_scope':'Counterbalancedtimings(count=numberofmodels), rangereported; no confidence-intervalorequalaccuracyclaim.'};(H/'RESULTS.json').write_text(json.dumps(report,indent=2));print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
