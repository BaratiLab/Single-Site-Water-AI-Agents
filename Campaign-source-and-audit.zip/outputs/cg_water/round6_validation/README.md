# Round 6 independent candidate tests

The native mW reference in the sibling `round6_mw_comparison` directory is available to training. This directory is reserved for fresh tests of the next explicitly frozen candidate. Preparing these scripts does not mean candidate MD has run.

Before any candidate trajectory starts, record the exact model SHA256, bind the specified native engine, and pass the candidate’s 1 fs mechanical checks. Keep a byte-identical local model copy. Reserved seeds are 226611 + 89j for the five EOS states, 227119 for ambient NPT, and 228119 for the experimental RDF state. These seeds are excluded from training.

The protocols match the mW and previous-candidate tests: NPT at 298.15 K and 1 bar for 30 ps equilibration plus 150 ps production; five NVT EOS states for 10 ps equilibration plus 60 ps production each; and a separate NVT RDF test at 295.15 K and density 0.997772886443 g/cm³ for 10 ps plus 60 ps. Every run uses 512 beads and a 1 fs timestep.

`PREDECLARED_PROTOCOL.json` and `LOCKED_CONSTRAINTS.json` preserve the gates before candidate testing. The primary compressibility, expansion and pressure–temperature gates use EOS central estimates. NPT fluctuations and canonical covariances are independent consistency checks, not favorable alternatives selected after seeing results. Mean tolerance passage alone does not establish accuracy. Uncertainty, drift and any disagreement remain visible.

The experimental RDF comparison uses the shared `round6_reference/reference.py` implementation: exact r²-weighted shell averages of the original numerical Skinner curve, 0.05 Å bins, and the 2.4–5.8 Å RMS range. Point-interpolation sensitivity and the authors’ estimated-error curve are retained. Those errors are not treated as an independent Gaussian likelihood. OPC3 comparisons remain separate diagnostics.

`run_npt.py`, `run_cross.py` and `run_structure_state.py` produce raw trajectories and complete reports. `canonical.py` reproduces the covariance response checks. `gates.py` reports every locked tolerance and its normalized discrepancy without a compensating weighted score. A passing candidate may progress to conditional thermal, interface and transport tests after coordination with the parent task. Failed gates are reported; the frozen model is not retuned against these trajectories. Old diffusion, friction, caloric closures and phase results do not transfer to a changed Hamiltonian.
