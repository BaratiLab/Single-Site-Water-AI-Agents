from pathlib import Path
import hashlib,json,zipfile
import subprocess,re,fitz
def pages(p):return int(re.search(r"Pages:\s+(\d+)",subprocess.check_output(["pdfinfo",str(p)],text=True))[1])
D=Path(__file__).resolve().parent
for stem in ['main','supplement']:
 text='\n'.join(p.get_text() for p in fitz.open(D/(stem+'.pdf')))
 assert 'Agentic Swarm Discovery of Single-Site Water Molecule' in ' '.join(text.split())
 assert '??' not in text
 assert 'Overfull' not in (D/(stem+'.log')).read_text()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(D/'model/frozen_c34.json')=='b465820825ebda1337ac11ada2ac3942e1ed5ab287aed7c439a6d7cc3c29070c'
files=[p for p in D.rglob('*') if p.is_file() and 'qa' not in p.relative_to(D).parts and p.suffix not in {'.log','.blg','.aux','.out','.dylib','.so'} and p.name not in {'ASSET_MANIFEST.json','DELIVERY_STATUS.json'}]
m={'title':'Agentic Swarm Discovery of Single-Site Water Molecule','model_SHA256':sha(D/'model/frozen_c34.json'),'main_pages':pages(D/'main.pdf'),'supplement_pages':pages(D/'supplement.pdf'),'verification':'Both PDFs compiled and visually reviewed; no unresolved citations or overfull boxes. Scientific qualification NOT QUALIFIED remains explicit.','files':[{'path':str(p.relative_to(D)),'sha256':sha(p)} for p in sorted(files)]}
(D/'ASSET_MANIFEST.json').write_text(json.dumps(m,indent=2));files.append(D/'ASSET_MANIFEST.json')
zpath=D.parent/'Agentic Swarm Discovery of Single-Site Water Molecule.zip'
with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,p.relative_to(D))
with zipfile.ZipFile(zpath) as z:
 assert all(hashlib.sha256(z.read(r['path'])).hexdigest()==r['sha256'] for r in m['files'])
print(json.dumps({'zip':str(zpath),'bytes':zpath.stat().st_size,'files':len(files),'SHA256':sha(zpath),'pages':[m['main_pages'],m['supplement_pages']]}))
