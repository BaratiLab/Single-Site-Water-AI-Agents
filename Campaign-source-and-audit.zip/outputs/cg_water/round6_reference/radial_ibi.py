"""Regularized radial proposal from measured simulation-to-experiment RDF.
This is an IBI proposal, not a unique pair potential or a claim of MD accuracy.
It must be jointly tested against pressure and response functions by fresh MD.
"""
from pathlib import Path
import copy,json
import numpy as np
from scipy.interpolate import CubicSpline
from scipy.signal import savgol_filter
KB=.008314462618

def propose(model, rdf_npz, relaxation=.3, max_update_kJ=1.5):
 z=np.load(rdf_npz);r=z['r_A'];g=z['g'];target=z['experimental_shell_average']
 correction=KB*295.15*np.log(np.maximum(g,.04)/np.maximum(target,.04))
 correction=savgol_filter(np.clip(correction,-max_update_kJ,max_update_kJ),9,3)*relaxation
 k=np.asarray(model['pair_knots_A']);lo=max(2.2,float(k[0]));hi=float(k[-1])
 def smoothstep(t):
  t=np.clip(t,0,1);return t**3*(10-15*t+6*t*t)
 envelope=smoothstep((r-lo)/.3)*smoothstep((hi-r)/.5)
 vals=np.interp(k,r,correction*envelope,left=0,right=0)
 vals[(k<=lo)|(k>=hi)]=0
 delta=CubicSpline(k,vals,bc_type=((1,0),(1,0)))
 out=copy.deepcopy(model)
 out['pair_coefficients_descending']=(np.asarray(model['pair_coefficients_descending'])+delta.c).tolist()
 out['radial_IBI_proposal']={'relaxation':relaxation,'max_raw_update_kJ_mol':max_update_kJ,'source':str(Path(rdf_npz).resolve()),'reference_T_K':295.15,'nominal_envelope_support_A':[lo,hi],'scope':'Regularized IBI proposal with smooth sampled envelope and global clamped cubic interpolation. Small between-knot oscillations outside nominal envelope are possible; exact compact core preservation is not claimed. Requires actual joint MD validation. Pairwise representability is not assumed.'}
 return out

if __name__=='__main__':
 D=Path(__file__).resolve().parent;B=D.parent
 m=json.loads((B/'round5_mw_poly/candidate.json').read_text())
 rdf=B/'round6_mw_comparison/experimental295/RDF_COMPARISON.npz'
 for i,relax in enumerate([.3,.6]):
  out=propose(m,rdf,relaxation=relax)
  (D/f'mW_IBI_proposal_{i}.json').write_text(json.dumps(out,indent=2))
 print('Created untested IBI proposals only; no MD or fitting success claimed.')
