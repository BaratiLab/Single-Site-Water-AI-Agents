import os
for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
from pathlib import Path
import sys,json,hashlib,time,copy
import numpy as np
from scipy.interpolate import CubicSpline
D=Path(__file__).resolve().parent;B=D.parent
sys.path.insert(0,str(B/'round6_engine'));from native import run
from analyze import energy,isolated,EDGES,R,TARGET
C=json.loads((D/'LOCKED_CONSTRAINTS.json').read_text());rho0=C['reference_density_g_cm3'];kb=.008314462618

def radial(m,a,b,c):
 k=np.array(m['pair_knots_A']);co=np.array(m['pair_coefficients_descending']);v=np.r_[co[3],0.];dx=k[-1]-k[-2];dr=3*co[0,-1]*dx*dx+2*co[1,-1]*dx+co[2,-1]
 def bump(lo,hi):
  z=np.clip((k-lo)/(hi-lo),0,1);return 64*z**3*(1-z)**3
 z=np.clip((k-2.4)/.9,0,1);v+=a*bump(2.4,3.3)+b*(2*z-1)*bump(2.4,3.3)+c*bump(3.1,4.2)
 m['pair_coefficients_descending']=CubicSpline(k,v,bc_type=((1,float(co[2,0])),(1,float(dr)))).c.tolist()

def prepare():
 z=np.load(D/'baseline_seed0/trajectory.npz');x=z['positions_A'][-1];L=float(z['cell_A'][-1,0]);models=[]
 for q in range(8):
  seed=q%2;m=json.loads((D/f'seed{seed}_baseline.json').read_text());label='exact_seed_control'
  if q>=2:
   e=m['embedding'];n=float(np.mean(energy(m,x,L)[1]));center=e['n0'] if seed==0 else n;e.update(n0=center,K2=([.5,-2,.5,-4,.941,-2][q-2]),h3=([0,0,-.5,-.3,.5,.3][q-2]),h4=([.25,1,.5,2,.5,1][q-2]))
   lam=m['lambda_kJ_mol'];l0=[200,lam,180,lam,200,lam][q-2];l1=[40,0,-60,-150,100,150][q-2];l2=[10,0,20,30,20,30][q-2];m['angular_polynomial']={'l0':l0,'l1':l1,'l2':l2,'nref':center};radial(m,[-.2,-.25,-.15,-.25,.2,-.15][q-2],[.25,-.2,-.25,.3,.4,-.3][q-2],[.15,.15,.2,.15,-.2,-.15][q-2]);label='joint_two_shell_generalL_stabilized_embedding'
   # Frozen-frame two-dimensional response: pressure and gas-liquid cohesion.
   frames=z['positions_A'][-4:];eps=1e-4
   def metrics(mm):
    ens=[];ps=[]
    for f in frames:
     E=energy(mm,f,L)[0];us=(energy(mm,f,L,np.exp(eps))[0]-energy(mm,f,L,np.exp(-eps))[0])/(2*eps);ens.append(E/64);ps.append(-us/(3*L**3)*16605.39067+63*kb*298.15/L**3*16605.39067)
    return np.array([np.mean(ps),isolated(mm)-np.mean(ens)+kb*298.15])
   base=metrics(m);mk=copy.deepcopy(m);mk['embedding']['K1']+=1;mr=copy.deepcopy(m);radial(mr,1,0,0);J=np.column_stack((metrics(mk)-base,metrics(mr)-base));delta=np.linalg.lstsq(J,np.array([1,43.98748])-base,rcond=None)[0];delta=np.clip(delta,[-2,-2],[2,2]);m['embedding']['K1']+=float(delta[0]);radial(m,float(delta[1]),0,0);m['round6_static_counterterm']={'deltaK1':float(delta[0]),'first_shell_amplitude':float(delta[1]),'before':base.tolist(),'predicted_after':(base+J@delta).tolist(),'scope':'Four frozen c21 training frames; proposal only, relaxation measured below.'}
  p=D/f'candidate_{q:02d}.json';p.write_text(json.dumps(m,indent=2));models.append({'q':q,'seed_family':seed,'structure_label':label,'path':str(p)})
 (D/'BATCH1_SPECS.json').write_text(json.dumps(models,indent=2))

def evaluate(q):
 spec=next(v for v in json.loads((D/'BATCH1_SPECS.json').read_text()) if v['q']==q);p=Path(spec['path']);m=json.loads(p.read_text());z=np.load(D/f"baseline_seed{spec['seed_family']}/trajectory.npz");x=z['positions_A'][-1];old=float(z['cell_A'][-1,0]);states=[];central=None
 for j,(rho,T) in enumerate([(rho0,298.15),(rho0-.02,298.15),(rho0+.02,298.15),(rho0,278.15),(rho0,318.15)]):
  L=(64*18.01528/.602214076/rho)**(1/3);folder=D/f'q{q:02d}_s{j}';folder.mkdir(exist_ok=True);out=run(m,x/old*L,L,folder/'trajectory',T=T,steps=20000,equil=5000,sample=100,dt_fs=1,gamma_ps=5,seed=3262101+q*107+j*17,ensemble='nvt');P=out['pressure_bar'];states.append({'rho':rho,'T':float(out['temperature_K'].mean()),'P':float(P.mean()),'P_block_SE':float(np.std([v.mean() for v in np.array_split(P,4)],ddof=1)/2)})
  if j==0:central=out
 A=np.array([[1,s['rho']-rho0,s['T']-298.15] for s in states]);coef=np.linalg.lstsq(A,[s['P'] for s in states],rcond=None)[0];bulk=rho0*coef[1];hist=np.zeros(len(R));ii,jj=np.triu_indices(64,1);L=float(central['cell_A'][0,0]);frames=central['positions_A']
 for f in frames:
  d=f[jj]-f[ii];d-=L*np.rint(d/L);hist+=np.histogram(np.linalg.norm(d,axis=1),EDGES)[0]
 g=hist/(len(frames)*len(ii)*4*np.pi/3*np.diff(EDGES**3)/L**3);first=(R>=2.4)&(R<=3.4);mask=(R>=2.4)&(R<=5.8);ip=np.flatnonzero(first)[np.argmax(g[first])];props={'pressure_bar':float(coef[0]),'kappa_bar_inverse':float(1/bulk),'alpha_K_inverse':float(coef[2]/bulk),'P_T_bar_K':float(coef[2]),'cohesion_proxy_kJ_mol':float(isolated(m)-central['potential_kJ_mol'].mean()/64+kb*central['temperature_K'].mean()),'peak_height':float(g[ip]),'peak_position_A':float(R[ip]),'experimental_RDF_RMSE':float(np.sqrt(np.mean((g[mask]-TARGET[mask])**2)))};viol={k:abs(v-C[k]['target'])/C[k]['tolerance'] for k,v in props.items()};score=max(viol.values()) if bulk>0 else 1e6;rec={'sequence':q,'trial_id':f'r6_c{q:02d}','stage':'N64_five_state_EOS_20ps','structure_label':spec['structure_label'],'seed_family':spec['seed_family'],'model_path':str(p.resolve()),'model_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'objective_value':float(score),'fitness':float(-score),'normalized_violations':viol,'feasible':bool(score<=1 and bulk>0),'properties':props,'states':states,'positive_bulk':bool(bulk>0),'completed_utc':time.time(),'RDF_comparison':'298.15 nominal vs295.15 experiment; 3K-offset screening only; exact-state test required','complexity':{'pair_intervals':len(m['pair_knots_A'])-1,'generalL':bool(m.get('angular_polynomial'))}};(D/f'TRIAL_{q:02d}.json').write_text(json.dumps(rec,indent=2));np.savez(D/f'RDF_{q:02d}.npz',r_A=R,g=g,target=TARGET);print(json.dumps(rec),flush=True)
if __name__=='__main__':
 if sys.argv[1]=='prepare':prepare()
 elif sys.argv[1]=='merge':
  rows=[json.loads(p.read_text()) for p in sorted(D.glob('TRIAL_*.json'))];rows.sort(key=lambda a:a['completed_utc']);[(r.update(sequence=i)) for i,r in enumerate(rows)];(D/'TRIALS.json').write_text(json.dumps(rows,indent=2))
 else:
  for q in range(int(sys.argv[1]),8,2):evaluate(q)
