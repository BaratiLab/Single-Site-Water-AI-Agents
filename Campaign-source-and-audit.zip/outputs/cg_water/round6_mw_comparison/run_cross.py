import os
from pathlib import Path
import sys,json,time,hashlib,argparse
import numpy as np
D=Path(__file__).resolve().parent;ROOT=D.parents[2];sys.path.insert(0,str(D.parent/os.environ.get('CG_VALIDATION_ENGINE','round6_mw_comparison')));from native import run
from analyze import blockstats,eos,structure
p=argparse.ArgumentParser();p.add_argument('model');p.add_argument('label');p.add_argument('--ps',type=float,default=60);p.add_argument('--N',type=int,default=512);p.add_argument('--seed',type=int,default=216611);p.add_argument('--sha',required=True);args=p.parse_args();m=Path(args.model).resolve();assert hashlib.sha256(m.read_bytes()).hexdigest()==args.sha;out=D/args.label;out.mkdir(exist_ok=True);start=time.time();reports=[]
init=np.load(D.parent/'pilot_pressure1_64.npz');x0=init['positions_A'][-1];L0=float(init['box_A'])
if args.N==512:
 init=np.load(D.parent.parent/'v7/round5/density512_seed83403_npt_trajectory.npz');x0=init['positions_A'][-1][::3];L0=float(init['cell_A'][-1,0,0])
for j,(T,rho) in enumerate([(298.15,.98),(298.15,.99705),(298.15,1.015),(288.15,.99705),(308.15,.99705)]):
 L=(args.N*18.01528/.602214076/rho)**(1/3);x=x0*L/L0;pre=out/f'state{j}';a=run(m,x,L,pre,T=T,steps=round(args.ps*1000),equil=10000,sample=100,dt_fs=1,gamma_ps=5,seed=args.seed+j*89);s,r,g=structure(a['positions_A'][::5],a['cell_A'][::5]);np.savez_compressed(str(pre)+'_rdf.npz',r_A=r,g=g);rep={'state':j,'target_T':T,'rho':rho,'temperature':blockstats(a['temperature_K']),'pressure':blockstats(a['pressure_bar']),'structure':s};reports.append(rep);(out/'STATES.json').write_text(json.dumps(reports,indent=2));print(json.dumps(rep),flush=True)
summary={'engine_directory':os.environ.get('CG_VALIDATION_ENGINE','round6_mw_comparison'),'model':str(m),'sha256':hashlib.sha256(m.read_bytes()).hexdigest(),'N':args.N,'equil_ps':10,'production_ps':args.ps,'gamma_ps_inverse':5,'EOS':eos(reports),'states':reports,'wall_seconds':time.time()-start};(out/'REPORT.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary['EOS']),flush=True)
