from pressure_polish import *
CONFIGS=[(5.,-2),(5.,-4),(5.5,-2),(5.5,-4)]
def prepare():
 specs=json.loads((D/'BATCH1_SPECS.json').read_text());parent=D/'candidate_16.json';prompt=B/'round6_llmsr/native_batch4/next_prompt.txt';z=np.load(D/'q16_s0/trajectory.npz');frames=z['positions_A'][-8::2];L=float(z['cell_A'][0,0]);eps=1e-4
 for q,(rd,K2) in enumerate(CONFIGS,28):
  m=json.loads(parent.read_text());kn=m['pair_knots_A'];co=np.array(m['pair_coefficients_descending']);extra=[v for v in [5.,5.5,6.] if v>kn[-1]+1e-8];m['pair_knots_A']=kn+extra;m['pair_coefficients_descending']=np.column_stack((co,np.zeros((4,len(extra))))).tolist();e=m['embedding'];e['rd']=rd;ns=np.concatenate([energy(m,x,L)[1] for x in frames]);n0=float(ns.mean());e.update(n0=n0,K2=K2,K1=0,h3=0,h4=.2);m['angular_polynomial'].update(nref=n0,l1=0,l2=0);m['undercoordination'].update(nstar=.5,A3=0,A4=0)
  def metrics(mm):
   en=[];pp=[]
   for x in frames:
    E=energy(mm,x,L)[0];u=(energy(mm,x,L,np.exp(eps))[0]-energy(mm,x,L,np.exp(-eps))[0])/(2*eps);en.append(E/64);pp.append(-u/(3*L**3)*16605.39067+63*kb*298.15/L**3*16605.39067)
   return np.array([np.mean(pp),isolated(mm)-np.mean(en)+kb*298.15])
  base=metrics(m);mk=copy.deepcopy(m);mk['embedding']['K1']+=1;mg=copy.deepcopy(m);mg['undercoordination']['A4']+=1;J=np.column_stack((metrics(mk)-base,metrics(mg)-base));delta=np.clip(np.linalg.lstsq(J,np.array([1,43.98748])-base,rcond=None)[0],[-10,0],[10,80]);m['embedding']['K1']+=float(delta[0]);m['undercoordination']['A4']=float(delta[1]);m['round6_broad_descriptor']={'parent_path':str(parent.resolve()),'parent_sha256':hashlib.sha256(parent.read_bytes()).hexdigest(),'feedback_prompt':str(prompt.resolve()),'feedback_prompt_sha256':hashlib.sha256(prompt.read_bytes()).hexdigest(),'radial_extension':'Exactzero additional cubic intervals; existingradialfunctionunchanged, physicalpairinteractioncutoff4.3065A, neighborcutoff6A','fixed_n0_matching_c16_frames':n0,'sampled_n_quantiles':np.quantile(ns,[0,.01,.5,.99,1]).tolist(),'static_base':base.tolist(),'static_deltaK1_A4':delta.tolist(),'static_prediction':(base+J@delta).tolist(),'hypothesis':'Firstshellcoordinationinsensitivetovolume: testbroadersmoothdensitydescriptor independentlyofpreservedradial/angularfunctions. StabilizedK2negative, fixednrefmean; actualMDresponsemustpass.'};p=D/f'RAW_proposal_{q:02d}.json';p.write_text(json.dumps(m,indent=2));specs.append({'q':q,'seed_family':1,'structure_label':f'feedback_broad_coordination_rd{rd}_K2{K2}_h4p2_constantL_sparseA4_actual_pressure_secant','path':str(D/f'candidate_{q:02d}.json')})
 specs={s['q']:s for s in specs};(D/'BATCH1_SPECS.json').write_text(json.dumps([specs[k] for k in sorted(specs)],indent=2))
if __name__=='__main__':
 if sys.argv[1]=='prepare':prepare()
 else:
  for q in range(28+int(sys.argv[1]),32,2):polish(q,D/f'RAW_proposal_{q:02d}.json',16);evaluate(q)
