"""Agent-in-the-loop adapter to the actual LLM-SR Sampler/Buffer/Evaluator.
No network backend is used. The current language-model agent authors candidates,
reads generated experience-buffer prompts, and writes the next proposal JSON.
The evaluator must implement evaluate_candidate(spec:dict)->dict with a 'score'
(higher is better). Training coefficient optimization and validation selection
belong in that evaluator. Test data must never enter its feedback.
"""
from __future__ import annotations
import argparse,ast,hashlib,importlib.util,json,sys,time
from pathlib import Path
import numpy as np
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parents[1]/'v2/vendor'))
from llmsr import sampler,buffer,config,code_manipulation,evaluator

SPEC='''"""Agent-in-the-loop joint symbolic search of neutral single-bead water.
Allowed invariant grammar: refitted radial cubic with independent first/second
shell updates; compact smooth coordination n; stabilized embedding quadratic,
cubic and quartic functions; strictly positive general angular strength
L(n)=l0+l1*delta_n+l2*delta_n**2; angular invariant A and positive polynomial
radial weight s**3*Q(s)**2. Prior constrained square L is also a reference.
Coordination support and fixed threshold functions differ by declared family.
An offline compact radial-coordinate warp is another proposed function family;
it is compiled into the runtime cubic and tested by actual MD before selection.
Models are proposed after simulation feedback. Training fitness prioritizes
worst normalized per-property violation; improvements cannot compensate for
failure of another required property. Final selection uses only same-budget
training refinement and a frozen rule, not native mixed-stage buffer ranking.
Experimental Skinner2013 gOO data at295.15K supersedes OPC3 as the primary
structural target. Authors estimated errors are not independent Gaussian data.
The evaluator verifies frozen parameter hashes and registers measured MD.
This finite agent-authored file-sampler search uses actual upstream LLM-SR
Sampler/Evaluator/ExperienceBuffer. Numerical fitting and MD are external;
no external LLM API and no exhaustive symbolic-optimum claim is made.
"""
@evaluate.run
def evaluate(data):
    return 0.0
@equation.evolve
def equation():
    """Return a literal function-family and recorded MD trial specification."""
    return {"sequence": 0, "label": "reference_0"}
'''

class FileProposalLLM(sampler.LLM):
    """Native sampling hook with transparent agent-authored proposal replay."""
    proposals=[];output=None;cursor=0
    def draw_samples(self,prompt,config):
        cls=type(self);item=cls.proposals[cls.cursor];cls.cursor+=1
        (cls.output/f'prompt_{cls.cursor:03d}.txt').write_text(prompt)
        (cls.output/f'proposal_{cls.cursor:03d}.json').write_text(json.dumps(item,indent=2))
        spec=item.get('spec',item)
        return ['    return '+repr(spec)+'\n']

class MolecularSandbox(evaluator.Sandbox):
    evaluate_fn=None; output=None;records=[]
    def run(self,program,function_to_run,function_to_evolve,inputs,test_input,timeout_seconds,**kwargs):
        start=time.time();record={}
        try:
            tree=ast.parse(program);node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name==function_to_evolve)
            returns=[n for n in node.body if isinstance(n,ast.Return)]
            if len(returns)!=1:raise ValueError('Require exactly one literal return')
            spec=ast.literal_eval(returns[0].value)
            digest=hashlib.sha256(json.dumps(spec,sort_keys=True).encode()).hexdigest()[:16]
            record={'id':digest,'spec':spec,'origin':'agent-authored continuation via native LLM-SR sampler'}
            result=type(self).evaluate_fn(spec)
            result={'score':float(result)} if isinstance(result,(float,int)) else result
            score=float(result['score']);record.update(result)
            if not np.isfinite(score):raise ValueError('Nonfinite fitness')
            ok=True
        except Exception as exc:
            record.update(error=f'{type(exc).__name__}: {exc}',score=None);score=None;ok=False
        record['wall_seconds']=time.time()-start;type(self).records.append(record)
        with (type(self).output/'evaluations.jsonl').open('a') as h:h.write(json.dumps(record)+'\n')
        return score,ok

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--proposals','--proposal-file',dest='proposals',required=True);ap.add_argument('--evaluator',required=True,help='Python file exposing evaluate_candidate(spec)');ap.add_argument('--out',default=str(HERE/'llmsr_run'));ap.add_argument('--seed',type=int,default=2026);args=ap.parse_args()
    np.random.seed(args.seed);out=Path(args.out);out.mkdir(parents=True,exist_ok=True)
    modspec=importlib.util.spec_from_file_location('water_llmsr_evaluator',args.evaluator);module=importlib.util.module_from_spec(modspec);sys.modules[modspec.name]=module;modspec.loader.exec_module(module)
    proposals=json.loads(Path(args.proposals).read_text());FileProposalLLM.proposals=proposals;FileProposalLLM.output=out;FileProposalLLM.cursor=0
    MolecularSandbox.evaluate_fn=staticmethod(getattr(module,'evaluate_spec',getattr(module,'evaluate_candidate',None)));MolecularSandbox.output=out;MolecularSandbox.records=[]
    cfg=config.Config(experience_buffer=config.ExperienceBufferConfig(num_islands=3),samples_per_prompt=1)
    template=code_manipulation.text_to_program(SPEC);db=buffer.ExperienceBuffer(cfg.experience_buffer,template,'equation')
    ev=evaluator.Evaluator(db,template,'equation','evaluate',{'train_validation':{}},sandbox_class=MolecularSandbox)
    # Seed every native island with the measured unchanged conservative CG baseline.
    ev.analyse('    return {"sequence": 0, "label": "reference_0"}\n',island_id=None,version_generated=None)
    if not any(r['score'] is not None for r in MolecularSandbox.records):raise RuntimeError('Baseline evaluator failed; inspect evaluations.jsonl')
    sampler.Sampler._global_samples_nums=1
    native=sampler.Sampler(db,[ev],1,cfg,max_sample_nums=len(proposals)+1,llm_class=FileProposalLLM)
    native.sample()
    prompt=db.get_prompt();(out/'next_prompt.txt').write_text(prompt.code)
    records=MolecularSandbox.records;good=[r for r in records if r.get('score') is not None]
    best=max(good,key=lambda r:r['score']);(out/'best_candidate.json').write_text(json.dumps(best,indent=2))
    manifest={'framework':'LLM-SR native Sampler, Evaluator, ExperienceBuffer, code_manipulation','source_commit':'41c212312df6c16d936c9cb395356a62774c47e3','sampler':'Agent-authored file continuation adapter; no API endpoint or secret required','proposals':len(proposals),'evaluated':len(records),'seed':args.seed,'best_id':best['id'],'best_score':best['score'],'next_round':'Read next_prompt.txt and evaluations.jsonl, author new function/term structures, append proposals and rerun to reconstruct native feedback buffer.'}
    snapshot=Path(args.evaluator).parent/'TRIALS_SNAPSHOT.json'
    if snapshot.exists():
        raw=snapshot.read_bytes();(out/'training_input_snapshot.json').write_bytes(raw);manifest['training_input_sha256']=hashlib.sha256(raw).hexdigest()
    (out/'manifest.json').write_text(json.dumps(manifest,indent=2));print(json.dumps(manifest,indent=2))
if __name__=='__main__':main()
