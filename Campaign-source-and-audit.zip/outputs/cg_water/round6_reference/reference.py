"""Skinner2013 experimental RDF at295.15K, volume averaged over MD shells.
The supplied estimated-error curve is NOT an independent Gaussian likelihood.
"""
from pathlib import Path
import numpy as np
D=Path(__file__).resolve().parent

def shell_average(edges, field='g'):
 z=np.load(D/'Skinner2013_gOO_295p15K.npz');r=z['r_A'];g=z[field]
 edges=np.asarray(edges,dtype=float)
 if not np.all(np.diff(edges)>0) or edges[0]<r[0]-1e-9 or edges[-1]>r[-1]+1e-9:raise ValueError('Invalid RDF shell edges')
 edges=edges.copy();edges[0]=max(edges[0],r[0]);edges[-1]=min(edges[-1],r[-1])
 values=[]
 for a,b in zip(edges[:-1],edges[1:]):
  x=np.r_[a,r[(r>a)&(r<b)],b];y=np.interp(x,r,g)
  slope=np.diff(y)/np.diff(x);intercept=y[:-1]-slope*x[:-1]
  integral=np.sum(slope*np.diff(x**4)/4+intercept*np.diff(x**3)/3)
  values.append(integral/((b**3-a**3)/3))
 return np.asarray(values)

def compare(r,g,edges=None):
 r=np.asarray(r);g=np.asarray(g)
 if edges is None:
  dr=np.diff(r)
  if not np.allclose(dr,dr[0]):raise ValueError('Need explicit nonuniform shell edges')
  edges=np.r_[r-dr[0]/2,r[-1]+dr[0]/2]
 target=shell_average(edges);z=np.load(D/'Skinner2013_gOO_295p15K.npz')
 out={}
 for end in [3.4,5.8]:
  m=(r>=2.4)&(r<=end)
  out[f'RMSE_2p4_{end:g}']=float(np.sqrt(np.mean((g[m]-target[m])**2)))
  out[f'point_interp_RMSE_2p4_{end:g}']=float(np.sqrt(np.mean((g[m]-np.interp(r[m],z['r_A'],z['g']))**2)))
 return out

if __name__=='__main__':
 e=np.arange(0,6.0001,.05);q=shell_average(e)
 assert np.all(np.isfinite(q)) and q.max()>2.5
 print({'shells':len(q),'peak_bin_average':float(q.max()),'temperature_K':295.15})
