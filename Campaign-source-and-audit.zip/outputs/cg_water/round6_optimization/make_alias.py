"""Exact zero-tail representation optimization. Explicit frozen SHA required; no import work."""
import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS']:os.environ[k]='1'
import argparse,json,hashlib,sys
from pathlib import Path
import numpy as np
H=Path(__file__).resolve().parent;B=H.parent;sys.path.insert(0,str(B/'round6_engine'));from native import create,run
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()

def main():
 p=argparse.ArgumentParser();p.add_argument('--primary',type=Path,required=True);p.add_argument('--sha256',required=True);p.add_argument('--trajectory',type=Path,required=True);a=p.parse_args();primarysha=sha(a.primary)
 if primarysha!=a.sha256:raise RuntimeError('Freeze SHA mismatch')
 raw=a.primary.read_bytes();(H/'frozen_primary.json').write_bytes(raw);m=json.loads(raw);k=np.array(m['pair_knots_A']);c=np.array(m['pair_coefficients_descending']);assert c.shape==(4,len(k)-1)
 nonzero=np.flatnonzero(np.any(c!=0,axis=0));last=int(nonzero[-1]) if len(nonzero) else -1;phi_support=float(k[last+1] if last>=0 else k[0]);rd=float(m.get('embedding',{}).get('rd',m['angular_cutoff_A']));rc=float(m['angular_cutoff_A']);cut=max(phi_support,rd,rc)
 if cut>=k[-1]:raise RuntimeError('No exact removable zero tail exists')
 if cut<=k[0]:raise RuntimeError('Invalid truncated interval domain')
 starts=k[k<cut];newk=np.r_[starts,cut];newc=c[:,:len(newk)-1].copy()
 if np.any(c[:,len(newk)-1:]!=0):raise RuntimeError('Attempt to remove nonzero polynomial coefficients')
 # A cutoff inside a retained interval is allowed only in the identically-zero tail.
 j=int(np.searchsorted(k,cut,side='left')-1)
 if k[j+1]!=cut and np.any(c[:,j]!=0):raise RuntimeError('Cannot split a nonzero radial interval')
 alias=json.loads(raw);alias['pair_knots_A']=newk.tolist();alias['pair_coefficients_descending']=newc.tolist();alias['representation_optimization']={'primary_sha256':primarysha,'old_neighbor_cutoff_A':float(k[-1]),'new_neighbor_cutoff_A':cut,'proof':'Every removed neighbor edge has identicallyzero radial polynomial and r>=angularrc andr>=coordinationrd. Allenergy,force,virialcontributions vanish. No potentialcoefficient fitting.'};aliaspath=H/'optimized_alias.json';aliaspath.write_text(json.dumps(alias,indent=2));aliassha=sha(aliaspath)
 z=np.load(a.trajectory);pos=z['positions_A'];cells=z['cell_A'] if 'cell_A' in z else None;idx=np.unique(np.linspace(0,len(pos)-1,20,dtype=int));rows=[]
 def evaluate(model,x,box,prefix):
  l=create(model,x,box,prefix);l.command('thermo_style custom step pe pxx pyy pzz pxy pxz pyz');l.command('run 0');E=l.get_thermo('pe')*4.184;F=np.array(l.gather_atoms('f',1,3)).reshape(-1,3)*4.184;P=np.array([l.get_thermo(n) for n in ['pxx','pyy','pzz','pxy','pxz','pyz']]);W=P*1.01325*np.prod(box)/16605.39067;l.close();return E,F,W
 for i in idx:
  box=cells[i] if cells is not None else z['box_A'];box=np.diag(box) if np.asarray(box).shape==(3,3) else np.broadcast_to(box,(3,));x=pos[i];old=evaluate(H/'frozen_primary.json',x,box,H/'primary_check');new=evaluate(aliaspath,x,box,H/'alias_check');rows.append({'frame':int(i),'energy_abs_error_kJ_mol':float(abs(old[0]-new[0])),'force_max_abs_error_kJ_mol_A':float(abs(old[1]-new[1]).max()),'six_virial_max_abs_error_kJ_mol':float(abs(old[2]-new[2]).max())})
 parity=all(r['energy_abs_error_kJ_mol']<1e-8 and r['force_max_abs_error_kJ_mol_A']<1e-8 and r['six_virial_max_abs_error_kJ_mol']<1e-8 for r in rows);report={'primary_sha256':primarysha,'optimized_alias_sha256':aliassha,'old_cutoff_A':float(k[-1]),'new_cutoff_A':cut,'true_radial_support_A':phi_support,'angular_support_A':rc,'coordination_support_A':rd,'removed_intervals_all_coefficients_exact_zero':True,'parity_rows':rows,'twenty_frame_parity_passed':parity,'status':'parity_passed_pending_NVE' if parity else 'failed','source_trajectory':str(a.trajectory),'source_trajectory_sha256':sha(a.trajectory),'engine_source_sha256':sha(B/'round6_engine/cg_moment.cpp'),'engine_binary_sha256':sha(B/'round6_engine/cg_moment.dylib'),'scope':'Exactrepresentationoptimizationofafrozenpotential, notnewfit. Neighborcutoffonly; sourcekernelandprimaryJSONunchanged.'};(H/'EQUIVALENCE_REPORT.json').write_text(json.dumps(report,indent=2))
 if not parity:raise RuntimeError('Alias parity failed; do not benchmark alias')
 x=pos[-1];box=cells[-1] if cells is not None else z['box_A'];box=np.diag(box) if np.asarray(box).shape==(3,3) else np.broadcast_to(box,(3,));out=run(aliaspath,x,box,H/'alias_nve_smoke',T=298.15,steps=2000,equil=0,sample=20,dt_fs=1,ensemble='nve',seed=917531);N=len(x);drift=float((out['total_kJ_mol'][-1]-out['total_kJ_mol'][0])/N);erange=float(np.ptp(out['total_kJ_mol'])/N);nve=bool(np.isfinite(out['total_kJ_mol']).all() and abs(drift)<.01 and erange<.02);report.update({'NVE_2ps_1fs_drift_kJ_mol_bead':drift,'NVE_energy_range_kJ_mol_bead':erange,'NVE_mean_temperature_K':float(out['temperature_K'].mean()),'NVE_smoke_passed':nve,'status':'passed' if nve else 'failed'});(H/'EQUIVALENCE_REPORT.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2));assert nve
if __name__=='__main__':
 try:main()
 except Exception as error:
  report_path=H/'EQUIVALENCE_REPORT.json'
  report=json.load(open(report_path)) if report_path.exists() else {}
  report.update({'status':'failed','execution_error':str(error),'alias_must_not_be_benchmarked':True})
  report_path.write_text(json.dumps(report,indent=2))
  raise
