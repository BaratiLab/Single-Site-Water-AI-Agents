"""Parameter admission tests only; zero MD timesteps."""
import json
from pathlib import Path
import numpy as np
from native import create,export,H
m=json.load(open(H.parent/'round5_fit/selected_candidate.json'));m['embedding']['K2']=-1.;m['embedding']['h4']=0
try:export(m,H/'guard_invalid_export.params');raise AssertionError('Unsafe export accepted')
except ValueError:pass
# Bypass Python admission so the native guard is tested independently.
valid=json.loads(json.dumps(m));valid['embedding']['h4']=1.;export(valid,H/'guard_positive.params');lines=(H/'guard_positive.params').read_text().splitlines();a=lines[-1].split();a[-1]='0';lines[-1]=' '.join(a);(H/'guard_invalid_native.params').write_text('\n'.join(lines)+'\n')
l=create(valid,np.array([[10.,10.,10.]]),30.,H/'guard_tmp');native_rejected=False
try:l.command(f'pair_coeff * * {H}/guard_invalid_native.params')
except Exception as e:native_rejected=True;message=str(e)
finally:l.close()
assert native_rejected
# Positive stabilization is admitted with negative K2, and legacy positive K2
# without higher embedding remains admitted. No dynamics are performed.
for model,name in [(valid,'negative_K2_stabilized'),(json.load(open(H.parent/'round5_fit/selected_candidate.json')),'legacy_positive_K2')]:
 l=create(model,np.array([[10.,10.,10.]]),30.,H/('guard_'+name));l.close()
r={'python_export_rejects_negative_K2_without_positive_h4':True,'native_rejects_same_unsafe_params_independently':native_rejected,'native_error':message,'negative_K2_positive_h4_accepted':True,'legacy_positive_K2_zero_h4_accepted':True,'MD_steps':0,'status':'passed'};(H/'STABILITY_GUARD_CHECK.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
