# Actual native mW reference comparison

Executed standard LAMMPS `pair_style sw`, originalreal-unitmWparameters epsilon6.189kcal/mol,sigma2.3925A,lambda23.15, no researchplugin orpolynomialapproximation. Nativeisolatedbeadenergyzero. Originalparameterfile,NISTmetal-unitsarchive,cross-unitrounding audit,fullinputs,seeds andhashesretained. NISTrounded0.268381eV converts6.1890129kcal/mol,2.08ppmfromoriginalpublished6.189usedhere.

Actual600ps MD: NPT512298.15K1bar30eq+150production; NVT512five-stateEOS10eq+60productioneach; extraNVT295.15K,rho.997772886443,10eq+60production forprimaryexperimentalRDF. All1fs,freshreferencevelocity/noiseseeds. Exact sameprotocols asindependentcandidatevalidation; resultsmayinformtraining because thisis theliteraturebaseline,notcandidateholdout. No timingspeedclaimfromconcurrentsampling.

|Property|Calculated|Reference|Unit|
|---|---:|---:|---|
|Density|0.99671966±0.000424|0.99704704|g/cm3|
|EOScompressibility|1.880336e-05|4.5246326e-05|1/bar|
|EOSexpansion|0.00025674729|0.00025728743|1/K|
|EOSpressure-temperaturecoefficient|13.654331|5.6863717|bar/K|
|NPTcompressibility|1.8409683e-05±1.24e-06|4.5246326e-05|1/bar|
|NPTexpansion|0.00021698526±3.32e-05|0.00025728743|1/K|
|Ideal-vaporcohesionproxy|44.646544±0.0112|43.98748|kJ/mol|
|EffectiveCGCp|31.262352±1.15|75.32763|J/mol/K|
|EffectiveCGCv|32.463914±2.42|74.53947|J/mol/K|
|ExperimentalRDFRMS|0.13181976±0.003|0|dimensionless|
|OOpeakposition|2.825|2.8|A|
|OOpeakheight|2.0809578|2.57|dimensionless|

EOS95descriptiveblock-bootstrap intervals:kappa[1.75557074776113e-05, 2.0282052653565037e-05],alpha[0.0001452594277461139, 0.0003639441596662828]. NominalT sensitivity{'kappa_bar_inverse': 1.8910043102708702e-05, 'alpha_K_inverse': 0.0002560595839621112}. Reference-densitypressureintercept=-16.58185bar. NPTdensityfirst/secondhalf=0.99611975/0.99731957; descriptivehalfdrift=1.513combinedblockSE.

mW matches density andthecentralexpansionestimate here, butcompressibilityisabout58%too low andEOSpressure-temperaturecoefficientis2.40timeswater. Theexpansionmatchcanthereforearise throughcompensatingmechanicalerrors(alpha=kappa*P_T). PredeclaredprimarymeanresearchgatesfailkappaandP_T; thisdoesnotdowngradethepublishedmodelusingqualifiedproductionresults—itidentifies limitationsunderourmatchedpilotprotocol.

CanonicalcovarianceP_T=6.583±5.965bar/K isnoisyversusEOS13.654; no choosingthemorefavorableestimate. EffectiveCGCp31.262±1.145 andCv32.464±2.421estimates overlapuncertainty; theirnegativepointdifferenceisnotaphysicalnegativeCp−Cvclaim. Theyarenotmolecularwaterheatcapacities andno caloricclosurewasapplied.

PrimaryRDFusesactual295.15Kexperimentalcurve,sharedexactr²shellintegrationover0.05Abins. Full2.4–5.8ARMSE=.13181976 withdescriptiveMDdeleteblockSE.00300346; pointinterpolationsensitivity=.13410898. Firstshell2.4–3.4ARMSE=.23845272. The.15researchmeangatepasses, butauthorestimatederrorslackfullcovariance andarenottreatedasindependentGaussianlikelihood. OPC3legacyRDFremainsaseparatediagnostic,notanexperimentalsurrogate.

Source:[MolineroandMoore2009](https://doi.org/10.1021/jp805227c),[NISTarchivedparameters](https://www.ctcms.nist.gov/potentials/entry/2009--Molinero-V-Moore-E-B--water/2009--Molinero-V--water--ipr-1.html),experimentalcurveprovenancein`round6_reference/SOURCE.json`. AllmWreferenceMDcompleted; no timingrunlaunched. NewcandidateholdoutrequiresitsownexplicitfreezeSHA,mechanicsgate andfreshseeds.
