"""Bounded subprocess queue: five EOS states plus matched experimental RDF."""
from pathlib import Path
import os,sys,json,time,argparse,subprocess
from concurrent.futures import ThreadPoolExecutor,as_completed
D=Path(__file__).resolve().parent;p=argparse.ArgumentParser();p.add_argument('model');p.add_argument('--sha',required=True);p.add_argument('--workers',type=int,default=3,choices=[1,2,3]);args=p.parse_args();M=str(Path(args.model).resolve());env=os.environ.copy();env.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1');jobs=[(f'eos_state{i}',[sys.executable,str(D/'run_eos_state.py'),M,'--sha',args.sha,'--state',str(i)]) for i in range(5)]+[('experimental295',[sys.executable,str(D/'run_structure_state.py'),M,'--sha',args.sha,'--out','experimental295','--seed','228119'])];start=time.time()
def execute(job):
 name,cmd=job;t=time.time()
 with (D/f'{name}.log').open('w') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=env)
 v={'name':name,'returncode':r.returncode,'elapsed_seconds':time.time()-t,'log':str(D/f'{name}.log')};print(json.dumps(v),flush=True);return v
results=[]
with ThreadPoolExecutor(max_workers=args.workers) as pool:
 future=[pool.submit(execute,j) for j in jobs]
 for f in as_completed(future):results.append(f.result())
report={'model':M,'sha256':args.sha,'max_NVT_processes':args.workers,'hardware_inventory':{'physical_cores':8,'performance_cores':4,'efficiency_cores':4},'NPT_process_reserved_separately':1,'jobs':results,'elapsed_seconds':time.time()-start,'all_successful':all(r['returncode']==0 for r in results),'scope':'Only independent state scheduling changed; seeds, integrators, lengths and estimators unchanged. No concurrent timing claim.'};(D/'NVT_DISPATCH_REPORT.json').write_text(json.dumps(report,indent=2))
if not report['all_successful']:raise SystemExit('One or more independent MD jobs failed; inspect unique logs, do not aggregate selectively.')
subprocess.run([sys.executable,str(D/'aggregate_eos.py')],env=env,check=True)
