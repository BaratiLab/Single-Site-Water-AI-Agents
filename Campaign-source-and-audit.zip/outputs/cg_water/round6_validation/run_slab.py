import os
"""Unfitted single-bead liquid-vapor slab pilot, no coexistence claim."""
import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
import sys,json,hashlib,time,argparse
from pathlib import Path
import numpy as np
BASE=Path(__file__).resolve().parent;p=argparse.ArgumentParser();p.add_argument('model');p.add_argument('--sha',required=True);args=p.parse_args();H=BASE/'slab';H.mkdir(exist_ok=True);B=BASE.parent;sys.path.insert(0,str(B/os.environ.get('CG_VALIDATION_ENGINE','round6_engine')));from native import create
M=Path(args.model).resolve();SHA=hashlib.sha256(M.read_bytes()).hexdigest();assert SHA==args.sha
x=np.array([[8,8,8],[10.8,8.3,8.1],[8.4,10.7,8.5],[8.2,8.8,10.8],[11.1,10.9,10.2]],float)
def evaluate(x):
 l=create(M,x,30.,H/'audit');l.command('thermo_style custom step pe press pxx pyy pzz');l.command('run 0');r=(l.get_thermo('pe')*4.184,np.array([l.get_thermo(a) for a in ['pxx','pyy','pzz']]));l.close();return r
E,P=evaluate(x);errs=[];eps=1e-6
for a in range(3):
 xp=x.copy();xm=x.copy();xp[:,a]*=1+eps;xm[:,a]*=1-eps;fd=(evaluate(xp)[0]-evaluate(xm)[0])/(2*eps);errs.append(abs(fd+P[a]*1.01325*30**3/16605.39067))
assert max(errs)<1e-4;(H/'DIAGONAL_VIRIAL_AUDIT.json').write_text(json.dumps({'xx_yy_zz_FD_errors_kJ_mol':errs,'scope':'Compact interiorcluster coordinateaffinedilation with noperiodiccrossingpairs; globaldiagonalvirialcheck, nottriclinicsupport.'},indent=2));print('AUDIT',errs,flush=True)
z=np.load(B/'round3_validation/finalist_npt/trajectory.npz');x=z['positions_A'][-1];old=z['cell_A'][-1];old=np.diag(old) if old.shape==(3,3) else old;N=len(x);L=(N*18.01528/.602214076/.99705)**(1/3);x=x/old*L;x[:,2]+=L;box=np.array([L,L,3*L]);l=create(M,x,box,H/'trajectory');l.commands_list(['thermo_style custom step temp pe ke press pxx pyy pzz','timestep 1','velocity all create 298.15 229113 mom yes rot no dist gaussian','fix bath all nvt temp 298.15 298.15 1000','run 50000']);rows=[];frames=[];start=time.time()
for j in range(1500):
 l.command('run 100 pre no post no');rows.append([l.get_thermo(a) for a in ['time','temp','pe','press','pxx','pyy','pzz']]);frames.append(np.array(l.gather_atoms('x',1,3)).reshape(N,3).copy())
 if (j+1)%200==0:print('PROGRESS',j+1,'/1500',time.time()-start,flush=True)
l.close();a=np.array(rows);np.savez_compressed(H/'SLAB_TRAJECTORY.npz',time_ps=a[:,0]*.001,temperature_K=a[:,1],potential_kJ_mol=a[:,2]*4.184,pressure_atm=a[:,3],diagonal_pressure_atm=a[:,4:],positions_A=frames,box_A=box);(H/'RUN.json').write_text(json.dumps({'engine_directory':os.environ.get('CG_VALIDATION_ENGINE','round6_engine'),'model_sha256':SHA,'N':N,'initial_liquid_density_g_cm3':.99705,'box_A':box.tolist(),'equilibration_ps':50,'production_ps':150,'dt_fs':1,'sample_ps':.1,'thermostat':'NoseHoover298.15K damping1ps','wall_seconds_production':time.time()-start,'scope':'Singlethin512beadslabpilot; no fitting, vaporpressure, coexistenceorboilingpointclaim. No analyticlongrangetailcorrection for compactlocalmodel.'},indent=2));print('COMPLETE',flush=True)
