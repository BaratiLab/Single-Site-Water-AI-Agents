from pathlib import Path
import json
D=Path(__file__).resolve().parent
r=json.loads((D/'N512_TRIAL_34.json').read_text());a=r['properties'];targets=json.loads((D/'LOCKED_CONSTRAINTS.json').read_text());allr=json.loads((D/'TRAINING_SELECTION.json').read_text())['all_largecell_trials'];budget=json.loads((D/'RUN_BUDGET.json').read_text());freeze=json.loads((D/'FREEZE.json').read_text())
text='''# Round 6: frozen joint water-potential calibration

Primary candidate **c34 is frozen for fresh validation**. It passes all eight fitted research gates by the training means. This is not an independently qualified water model: density has only been predicted from the training EOS, thermal uncertainty remains large, and transport, dielectric response, calorimetry and phase equilibria have not been validated for this candidate.

The model is a neutral, one-bead mechanical water potential. It combines a refitted radial cubic spline, a compact coordination descriptor with stabilized quartic embedding, a sparse lower-coordination correction and a tetrahedral angular invariant. The selected angular strength is constant; the independent density-angular functions were searched but do not survive in this primary model. Its polynomial angular radial weight is degree14 in Q, evaluated as t³Q(t)². This is a polynomial representation of invariant scalar functions, not a single global Cartesian polynomial.

## Frozen primary training results

'''
text+='|Observable|Reference|c34 training mean|Comparison|\n|---|---:|---:|---|\n'
labels={'pressure_bar':('Pressure / bar','absolute'),'kappa_bar_inverse':('Compressibility / bar⁻¹','relative'),'alpha_K_inverse':('Thermal expansion / K⁻¹','relative'),'P_T_bar_K':('Thermal pressure derivative / bar K⁻¹','relative'),'cohesion_proxy_kJ_mol':('Cohesion proxy / kJ mol⁻¹','relative'),'peak_height':('First peak height','relative'),'peak_position_A':('First peak position / Å','relative'),'experimental_RDF_RMSE':('Experimental RDF RMSE','rmse')}
for k,(name,mode) in labels.items():
 target=targets[k]['target'];v=a[k];comp=f'{v-target:+.2f} bar' if mode=='absolute' else f'{100*(v/target-1):+.2f}%' if mode=='relative' else 'research gate ≤0.15';text+=f'|{name}|{target:.8g}|{v:.8g}|{comp}|\n'
text+='''
EOS reference:298.15K and rho0=0.997047039g/cm³. The five-state fit uses measured mean temperatures, not thermostat targets. The cohesive quantity is the monatomic-CG isolated-minus-liquid potential-energy proxy plus RT; it is not a vapor–liquid coexistence calculation.

The RDF reference is the original Skinner2013 numerical oxygen–oxygen curve at295.15K. Exact r² shell averages are compared with0.05Å simulation bins over2.4–5.8Å. Published point-peak height2.57 and binned reference peak~2.538 are different estimators; the declared30% peak gate uses2.57. The RDF trajectory thermostat was295.15K and its actual mean was'''+f" {r['states'][5]['T']:.3f}K."+'''

The diagnostic five-block bootstrap ranges are broad: kappa4.44–7.88×10⁻⁵/bar, alpha−0.31–7.60×10⁻⁴/K and P_T−0.51–12.22bar/K. Five6ps blocks can underestimate slow correlations. These ranges do not establish converged accuracy or confidence-qualified feasibility.

## Selection and density

The strict original minmax winner was **c33**, score0.93529. Primaryc34 has score0.97300. An explicit **PRE-HOLDOUT selection amendment** chosec34 for lower predicted density risk among the two same-budget mean-feasible, near-tied candidates. It is incorrect to say that the original strict minmax rule selectedc34. c33 remains byte-exact in strict_minimax_candidate.json. SeeSELECTION_AMENDMENT.json for timing, training snapshot hash and the rule.

The global linear-EOS root predictsc34 density0.993217g/cm³ (−0.384%); a central-pressure-anchored prediction gives0.993647g/cm³ (−0.341%). Their diagnostic bootstrap intervals are0.988627–0.997164 and0.986527–1.000654g/cm³. These are model predictions, not measured NPT density success. c33 predictions were+0.699% and+0.568%, outside the intended0.5% density tolerance.

Linear-plane pressure can disagree with the directly sampled central pressure when the EOS curves. Forc34, planeP0=69.29bar, central T-corrected pressure61.63bar, and a saturated five-parameter quadratic-axis diagnostic givesP0=61.70bar, kappa5.6245×10⁻⁵/bar and alpha2.9707×10⁻⁴/K. The quadratic fit has five parameters for five means and is a sensitivity diagnostic, not an additional validation or a replacement ranking. c32 had a much larger plane/central disagreement; that failure is preserved.

Fresh NPT, EOS and matched-temperature RDF runs must test the frozen PRIMARYc34. A failed fresh test must be reported; the primary must not be retrospectively swapped toc33 using heldout outcomes.

## Same-budget larger-cell training comparisons

'''
text+='|Candidate|Worst normalized discrepancy|P / bar|kappa / bar⁻¹|alpha / K⁻¹|P_T / bar K⁻¹|RDF RMSE|\n|---|---:|---:|---:|---:|---:|---:|\n'
for rr in allr:
 p=rr['properties'];text+=f"|{rr['trial_id']}|{rr['objective_value']:.4f}|{p['pressure_bar']:.2f}|{p['kappa_bar_inverse']:.7g}|{p['alpha_K_inverse']:.7g}|{p['P_T_bar_K']:.3f}|{p['experimental_RDF_RMSE']:.4f}|\n"
text+='''
## Search, actual MD and lessons

There were32 actual five-state N64 screens, eight same-budget six-state N512 refinements and35 unique candidate models. N64 screens used5ps equilibration plus20ps production per state. N512 refinements used10ps equilibration plus30ps production per state, with a separate295.15K RDF state. Integration timestep was1fs; static-property trajectories used Langevin gamma5ps⁻¹. This thermostat does not validate diffusion or a physical CG clock.

The native upstream LLM-SR Sampler/Evaluator/ExperienceBuffer registered actual MD training fitness. Seven intermediate prompts and evaluation logs were read before adaptive proposals. The finite agent-authored grammar search used no external LLM API and does not prove a global symbolic optimum. The mW-like seed is a literature-informed polynomial approximation, not an ab-initio force-trained discovery. Original c21 and polynomial-mW controls are preserved.

The failed canonical Born/variance compressibility estimator differed~68% from an available training EOS check and was excluded from all candidate fitness. Actual finite-difference EOS replaced it. Initial static proposals also exposed poor ensemble overlap when c21 frames were used for the mW family; later proposals used matching-parent frames.

Pair-well cohesion compensation stiffened the liquid. A sparse lower-coordination quartic, with nstar=.50 chosen from the training lower tail, instead adjusts isolated-bead energy while barely acting in bulk liquid. This is not vapor-pressure or interface validation. Broader coordination support5.5Å produced a stronger compressibility response than the first-shell descriptor. Negative quadratic embedding is always stabilized by positive quartic embedding.

Large radial coordinate warps failed pressure/RDF or EOS stability and were rejected. A manifest positional-lookup bug caused four repeated-parent EOS runs; it was caught before warped-trial registration, preserved under diagnostic_wrong_spec_lookup, excluded from selection and corrected by explicit candidate identity lookup. All40 selected-search records now pass model-path and SHA256 audit.

The exact retained budget is **7.04ns of actual integration**, including failed/excluded diagnostics:5.00ns N64 and2.04ns N512,7,040,000 steps across250 complete trajectories. Aggregate reported LAMMPS loop time is2376.3s, accumulated across concurrent training. That is not exclusive benchmark time or OS CPU time and must not be used as a performance comparison.

## Remaining scientific limits

Positive ambient EOS slope, positive quartic stabilization and benign short-run density diagnostics are not proofs of phase stability or transferability. Freezing, boiling, vapor pressure, interfaces, cavities, high pressure, supercooling and isotope effects remain untested. The sparse low-coordination term especially requires gas-cluster and evaporation/coexistence checks. A neutral bead has no molecular dipole; dielectric response requires additional observables and field-consistent physics. Caloric internal degrees of freedom and a validated physical dynamics clock are absent.

Existing legacy metadata inside the frozen JSON records historical round3/round5 initialization. It does not describe the current fit or establish current property validation. FREEZE.json, this report, TRAINING_SELECTION.json and SELECTION_AMENDMENT.json provide current provenance. The selected JSON remains byte-exact.

## Artifacts

- selected_candidate.json and FREEZE.json: frozen primary and hash.
- SYMBOLIC_MODEL.md and selected_radial_coefficients.csv: exact symbolic descriptors and radial coefficients.
- TRIALS.json, IDENTITY_HASH_AUDIT.json and RUN_BUDGET.json: measured training records and audit.
- TRAINING_PROGRESS.png/pdf: bounded search, EOS tradeoffs and matched RDF curves.
- STABILITY_DIAGNOSTICS.json: finite-box minimum-distance, coordination and small-wavevector checks.
- NEXT_TERMS.txt: training-only lessons for future work, not additional fitting this round.
'''
text+=f"\nFrozen SHA256: `{freeze['model_sha256']}`.\n";(D/'REPORT.md').write_text(text)
# Human-readable compact selected expression precedes the exact generic definition.
p=D/'SYMBOLIC_MODEL.md';old=p.read_text();m=json.loads((D/'selected_candidate.json').read_text());e=m['embedding'];u=m['undercoordination'];l=m['angular_polynomial'];prefix=f'''The selected nonzero expression is

U = sum_pairs phi(r) + sum_i [ {e['K1']:.15g} d_i −2.8 d_i² +0.2 d_i⁴ +{u['A4']:.15g} max(0,1−2n_i)⁴ +{l['l0']:.15g} A_i ],

d_i=n_i−{e['n0']:.15g}, n_i=sum_j max(0,1−r_ij²/5.5²)³.
All scalar energy coefficients are kJ/mol. The angular invariant below uses cutoff4.3065Å and the recorded degree14 Q. The exact pair cubic has a physical cutoff4.3065Å; appended zero intervals extend only the neighbor representation to6Å.

'''
if 'The selected nonzero expression' not in old:p.write_text(old.replace('# Frozen symbolic potential\n\n','# Frozen symbolic potential\n\n'+prefix))
