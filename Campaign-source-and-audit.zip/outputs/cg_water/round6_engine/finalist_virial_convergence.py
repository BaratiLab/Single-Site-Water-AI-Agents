import json,hashlib
from pathlib import Path
import numpy as np
from native import create,H
M=H.parent/'round6_fit/selected_candidate.json';z=np.load(H.parent/'round6_fit/N512_q34_s0/trajectory.npz');x=z['positions_A'][-1];b=z['cell_A'][-1];b=np.diag(b) if np.asarray(b).shape==(3,3) else b

def calc(x,b):
 l=create(M,x,b,H/'virial_convergence_tmp');l.command('run 0');e=l.get_thermo('pe')*4.184;w=l.get_thermo('press')*1.01325*np.prod(b)*3/16605.39067;l.close();return e,w
E,W=calc(x,b);rows=[]
for h in [1e-4,3e-5,1e-5,3e-6,1e-6,3e-7,1e-7]:
 ep=calc(x*(1+h),b*(1+h))[0];em=calc(x*(1-h),b*(1-h))[0];fd=-(ep-em)/(2*h);rows.append({'relative_scale_step':h,'FD_virial_kJ_mol':float(fd),'abs_error_kJ_mol':float(abs(fd-W)),'relative_error':float(abs(fd-W)/abs(W))})
r={'model_sha256':hashlib.sha256(M.read_bytes()).hexdigest(),'analytic_virial_kJ_mol':float(W),'rows':rows,'scope':'FDstepsensitivityauditwithoutmodelretuning; actualQ14Hornerandsystemenergycancellation canlimitverysmallsteps.'};(H/'FINALIST_VIRIAL_CONVERGENCE.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
