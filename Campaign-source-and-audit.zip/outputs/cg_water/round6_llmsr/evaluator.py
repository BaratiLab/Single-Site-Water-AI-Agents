"""Measured-MD backend; only frozen training records enter LLM-SR feedback."""
from pathlib import Path
import json,hashlib
D=Path(__file__).resolve().parent
def evaluate_candidate(spec):
    records=json.loads((D/'TRIALS_SNAPSHOT.json').read_text())
    seq=spec.get('sequence',0)
    if not isinstance(seq,int):raise ValueError('Integer training sequence required')
    r=next(r for r in records if r['sequence']==seq)
    p=Path(r['model_path'])
    if not p.exists():p=D.parent/'round6_fit'/p.name
    sha=hashlib.sha256(p.read_bytes()).hexdigest()
    if sha!=r['model_sha256']:raise ValueError('Recorded model changed after MD')
    if spec.get('model_sha256',sha)!=sha:raise ValueError('Wrong proposal model hash')
    return {'score':float(r['fitness']),'training_objective':r['objective_value'],
            'training_stage':r['stage'],'model_sha256':sha,'trial_id':r['trial_id'],
            'sequence':seq,'structure_label':r['structure_label'],
            'scope':'Cached actual training MD; coefficient search external, no held-out records.'}
