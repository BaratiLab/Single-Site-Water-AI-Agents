Experimental reference acquired before round6 fitting

Ambient_water_xray_data.txt contains the original six-column Skinner et al.
2013 numerical benchmark, mirrored in the primary Sullivan et al.2025 research
repository. SOURCE.json pins the exact commit, download URLs and file hashes.
The file header identifies measurement at22.0C=295.15K, not298.15K.
Columns are Q, Ix(Q), Soo(Q), r, goo(r), estimated error. The derived gOO uses
a modification-function Fourier transform and has experimental/inversion
limitations. It is not an exact underlying pair correlation without uncertainty.

Primary original paper: https://doi.org/10.1063/1.4790861
Repository: https://github.com/hoepfnergroup/LiquidStructureGP-Sullivan
Mirror study: https://arxiv.org/abs/2507.07948

Skinner2013_gOO_295p15K.npz is a direct parse of columns4–6. reference.py
volume-averages the piecewise-linear curve exactly over MD spherical shells.
The estimated-error field is preserved; no independent Gaussian likelihood or
uncertainty-of-the-mean is inferred because full covariance is unavailable.
The full experimental RDF replaces simulated OPC3 as the primary shape target
in round6. Previous round5 scores/frozen records are not retroactively changed.

The optional Sullivan_PhysGP_OO_r.txt is a later GP posterior reconstruction,
NOT the original experimental curve and NOT used as the fitting target here.
It is retained only to make the acquisition source unambiguous. MIT license
from the mirror repository is included; cite the original data creators.

PREVIOUS_MODELS_DIAGNOSTIC.json compares old298.15K curves with295.15K data,
explicitly a3K-offset exploratory diagnostic. New fitting/validation separately
simulates295.15K at IAPWS density0.997772886443g/cm3.
