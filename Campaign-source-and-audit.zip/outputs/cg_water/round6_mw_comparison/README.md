# Native mW reference: matched water-property tests

These are actual simulations with stock LAMMPS `pair_style sw`, using the original mW parameters in real units. They are **not** simulations with a polynomial approximation to mW.

The completed reference contains 600 ps of local MD, all with 512 beads and a 1 fs timestep:

- Ambient NPT: 30 ps equilibration and 150 ps production at 298.15 K and 1 bar.
- Five-state NVT EOS: 10 ps equilibration and 60 ps production per state, with the same temperatures, densities and estimator as the candidate tests.
- Experimental RDF test: 10 ps equilibration and 60 ps production at 295.15 K and the IAPWS density, 0.997772886443 g/cm³.

| Observable | mW reference | Experimental/IAPWS reference |
|---|---:|---:|
| Density, g/cm³ | 0.996720 ± 0.000424 | 0.997047 |
| EOS compressibility, 10⁻⁵/bar | 1.880 | 4.525 |
| EOS expansion, 10⁻⁴/K | 2.567 | 2.573 |
| EOS pressure–temperature coefficient, bar/K | 13.654 | 5.686 |
| Ideal-vapor cohesion proxy, kJ/mol | 44.647 | 43.987 |
| Matched experimental RDF RMS, 2.4–5.8 Å | 0.13182 | 0 |

The central expansion estimate agrees closely, while compressibility is about 58% too low. The pressure–temperature coefficient is too large. Thus the expansion agreement can result from compensating mechanical errors, through α = κ(∂P/∂T)ρ. The locked research gates fail compressibility and this pressure–temperature coefficient. They pass the other central-value thresholds, including the preliminary RDF threshold of 0.15; that is not a certificate of experimental accuracy.

RDF comparisons use the actual Skinner 2013 numerical curve at 295.15 K, with exact r²-weighted shell averages in 0.05 Å bins. Point-interpolation sensitivity is retained. Authors’ estimated errors are preserved, without treating them as independent Gaussian measurements. OPC3 remains a separate legacy diagnostic.

Block errors are descriptive. The canonical pressure–temperature covariance estimate is particularly noisy, 6.58 ± 5.96 bar/K, and is not selected instead of the EOS estimate. Effective bead heat capacities exclude eliminated molecular thermodynamics. Their short-trajectory Cp and Cv point estimates overlap uncertainties; they do not establish a physical negative Cp−Cv. The cohesion proxy uses the exact isolated-bead energy and is not a phase-coexistence enthalpy of vaporization.

`RESULTS.json`, `PROPERTY_COMPARISON.csv`, `GATES.json` and `REPORT.md` retain all results and qualifications. `MW_REFERENCE.png`/`.pdf` shows the direct experimental RDF comparison and the gate tradeoffs. Native input files, trajectories, scripts, seeds and hashes are retained. No computational speedup is inferred from concurrent sampling runs, and no timing job has been launched here.

The original parameters are from [Molinero and Moore, 2009](https://doi.org/10.1021/jp805227c). `PARAMETER_AUDIT.json` cross-checks the [NIST archived implementation](https://www.ctcms.nist.gov/potentials/entry/2009--Molinero-V-Moore-E-B--water/2009--Molinero-V--water--ipr-1.html), including its rounded metal-unit energy conversion. Experimental RDF provenance and its pinned repository commit are in the sibling `round6_reference` directory.

This literature reference may inform training. A new candidate still requires an explicit model freeze, mechanical checks and fresh independent trajectories.
