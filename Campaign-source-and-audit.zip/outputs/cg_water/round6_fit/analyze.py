from pathlib import Path
import sys,json
import numpy as np
D=Path(__file__).resolve().parent;B=D.parent;sys.path.insert(0,str(B/'round6_reference'));import reference
KB=.008314462618;UNIT=16605.39067
EDGES=np.arange(0,6.00001,.05);R=.5*(EDGES[1:]+EDGES[:-1]);TARGET=reference.shell_average(EDGES)

def energy(m,x,L,scale=1.):
 d=x[None,:,:]-x[:,None,:];d-=L*np.rint(d/L);d*=scale;r2=np.sum(d*d,axis=2);r=np.sqrt(r2);valid=r2>1e-14;n=len(x);ii,jj=np.triu_indices(n,1);rp=r[ii,jj];kn=np.array(m['pair_knots_A']);c=np.array(m['pair_coefficients_descending']);idx=np.clip(np.searchsorted(kn,rp,side='right')-1,0,len(kn)-2);z=rp-kn[idx];v=((c[0,idx]*z+c[1,idx])*z+c[2,idx])*z+c[3,idx];below=rp<kn[0];zz=rp[below]-kn[0];v[below]=c[3,0]+c[2,0]*zz+1e4*zz**4;v[rp>=kn[-1]]=0;E=v.sum()
 e=m.get('embedding',{});rd=e.get('rd',5);nd=np.sum(np.where(valid,np.maximum(0,1-r2/rd**2)**3,0),axis=1);dn=nd-e.get('n0',0);E+=np.sum(e.get('K1',0)*dn+e.get('K2',0)*dn**2+e.get('h3',0)*dn**3+e.get('h4',0)*dn**4);under=m.get('undercoordination',{});s=np.maximum(0,1-nd/under.get('nstar',1));E+=np.sum(under.get('A3',0)*s**3+under.get('A4',0)*s**4)
 s=np.maximum(0,1-r2/m['angular_cutoff_A']**2);Qp=np.polynomial.polynomial.polyval(s,m.get('angular_weight',{}).get('coefficients_ascending',[1.]));w=np.where(valid,s**3*Qp**2,0);u=d/np.where(valid,r,1)[:,:,None];A=w.sum(axis=1);S=np.einsum('ij,ija->ia',w,u);Q=np.einsum('ij,ija,ijb->iab',w,u,u);ai=.5*(np.sum(Q*Q,axis=(1,2))+2/3*np.sum(S*S,axis=1)+A*A/9-16/9*np.sum(w*w,axis=1));ap=m.get('angular_polynomial')
 if ap:
  z=nd-ap['nref'];lam=ap['l0']+ap.get('l1',0)*z+ap.get('l2',0)*z*z
 else:
  a=m.get('angular_coordination',{});lam=m['lambda_kJ_mol']*(1+a.get('b',0)*(nd-a.get('nref',0)))**2
 E+=np.sum(lam*ai);return float(E),nd,ai

def analyze(m,path,born_frames=100):
 z=np.load(path);x=z['positions_A'];N=x.shape[1];L=float(z['cell_A'][0,0]);V=L**3;T=z['temperature_K'];P=z['pressure_bar'];U=z['potential_kJ_mol'];tm=float(T.mean());Pconf=P-(N-1)*KB*T/V*UNIT;Us_native=-3*V/UNIT*Pconf;indices=np.linspace(0,len(x)-1,min(born_frames,len(x)),dtype=int);ss=[];energyerr=[];virialerr=[];nrange=[];eps=2e-4
 for i in indices:
  E,n,ai=energy(m,x[i],L);Ep,_,_=energy(m,x[i],L,np.exp(eps));Em,_,_=energy(m,x[i],L,np.exp(-eps));ss.append((Ep-2*E+Em)/eps**2);energyerr.append(E-U[i]);virialerr.append((Ep-Em)/(2*eps)-Us_native[i]);nrange.extend([n.min(),n.max()])
 Uss=float(np.mean(ss));variance=float(np.var(Us_native,ddof=1));bulk=float(P.mean()+UNIT/(9*V)*(Uss-variance/(KB*tm)));pt=float((N-1)*KB/V*UNIT+np.cov(Pconf,U,ddof=1)[0,1]/(KB*tm*tm));hgas=isolated(m);H=hgas-U/N+KB*T
 hist=np.zeros(len(R));ii,jj=np.triu_indices(N,1)
 for f in x[::2]:
  d=f[jj]-f[ii];d-=L*np.rint(d/L);hist+=np.histogram(np.linalg.norm(d,axis=1),EDGES)[0]
 g=hist/(len(x[::2])*len(ii)*(4*np.pi/3*np.diff(EDGES**3))/V);mask=(R>=2.4)&(R<=5.8);first=(R>=2.4)&(R<=3.4);ip=np.flatnonzero(first)[np.argmax(g[first])];props={'pressure_bar':float(P.mean()),'kappa_bar_inverse':float(1/bulk),'alpha_K_inverse':float(pt/bulk),'P_T_bar_K':pt,'cohesion_proxy_kJ_mol':float(H.mean()),'peak_height':float(g[ip]),'peak_position_A':float(R[ip]),'experimental_RDF_RMSE':float(np.sqrt(np.mean((g[mask]-TARGET[mask])**2)))}
 diagnostics={'N':N,'mean_T_K':tm,'rho_imposed_g_cm3':float(z['density_g_cm3'].mean()),'bulk_modulus_bar':bulk,'Born_mean_Uss_kJ_mol':Uss,'config_Us_variance':variance,'energy_max_error_kJ_mol':float(np.max(abs(np.array(energyerr)))),'Us_FD_vs_native_max_kJ_mol':float(np.max(abs(np.array(virialerr)))),'sampled_coordination_range':[float(min(nrange)),float(max(nrange))],'Born_frames':len(indices),'trajectory_frames':len(x),'experimental_RDF_offset_K':tm-295.15,'Born_formula':'K=P + (<Uss>-betaVar(Us))/(9V); P includes ideal and -Us/(3V), hence geometric -3Us term. Configurational Us only; measured kinetic contribution removed.'};return props,diagnostics,R,g

def isolated(m):
 e=m.get('embedding',{});u=m.get('undercoordination',{});n=e.get('n0',0);return e.get('K2',0)*n*n-e.get('K1',0)*n-e.get('h3',0)*n**3+e.get('h4',0)*n**4+u.get('A3',0)+u.get('A4',0)

if __name__=='__main__':
 m=json.loads((B/'round5_fit/selected_candidate.json').read_text());p=B/'round5_fit/adaptiveN512_c21_s0/trajectory.npz';props,diag,_,_=analyze(m,p,80);(D/'BORN_OLD_EOS_CHECK.json').write_text(json.dumps({'properties':props,'diagnostics':diag,'reference_round5_EOS_kappa':4.540945752062115e-5,'scope':'Priorround5training, nowexplicitlyround6training check. Bornformula validation, notnewfitresult.'},indent=2));print(json.dumps({'properties':props,'diagnostics':diag},indent=2))
