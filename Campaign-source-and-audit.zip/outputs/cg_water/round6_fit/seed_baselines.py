import os
for key in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[key]='1'
from pathlib import Path
import sys,json,hashlib,time
import numpy as np
D=Path(__file__).resolve().parent;B=D.parent;sys.path.insert(0,str(B/'round6_engine'));from native import run
sources=[B/'round5_fit/selected_candidate.json',B/'round5_mw_poly/candidate.json'];z=np.load(B/'round5_fit/adaptiveN64_c21_s0/trajectory.npz');x=z['positions_A'][-1];old=z['cell_A'][-1];L=(64*18.01528/.602214076/.99705)**(1/3);x=x/old*L
for q,src in enumerate(sources):
 m=json.loads(src.read_text());folder=D/f'baseline_seed{q}';folder.mkdir(exist_ok=True);p=D/f'seed{q}_baseline.json';p.write_text(json.dumps(m,indent=2));out=run(m,x,L,folder/'trajectory',T=298.15,steps=40000,equil=10000,sample=100,dt_fs=1,gamma_ps=5,seed=3261101+q*111,ensemble='nvt');rec={'trial_id':q,'stage':'N64_canonical_screen','structure_label':'c21_seed_baseline' if q==0 else 'literature_poly_mW_seed_baseline','model_path':str(p),'model_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'trajectory_path':str(folder/'trajectory.npz'),'N':64,'equilibration_ps':10,'production_ps':40,'mean_T_K':float(out['temperature_K'].mean()),'mean_P_bar':float(out['pressure_bar'].mean()),'status':'ActualMDcomplete; canonical/BornandRDFanalysispending'};(folder/'RUN.json').write_text(json.dumps(rec,indent=2));print(json.dumps(rec),flush=True)
