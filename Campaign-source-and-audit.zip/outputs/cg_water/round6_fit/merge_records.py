from pathlib import Path
import json,numpy as np
D=Path(__file__).resolve().parent;rho0=.997047039;rng=np.random.default_rng(983611)
rows=[]
for p in sorted(D.glob('TRIAL_*.json')):
 r=json.loads(p.read_text());q=int(r['trial_id'][-2:]);blocks=[]
 for j in range(5):
  z=np.load(D/f'q{q:02d}_s{j}/trajectory.npz');blocks.append(np.array([[a.mean(),b.mean()] for a,b in zip(np.array_split(z['pressure_bar'],4),np.array_split(z['temperature_K'],4))]))
 vals=[]
 for b in range(400):
  means=np.array([v[rng.integers(0,4,4)].mean(axis=0) for v in blocks]);A=np.array([[1,s['rho']-rho0,t-298.15] for s,t in zip(r['states'],means[:,1])]);c=np.linalg.lstsq(A,means[:,0],rcond=None)[0];K=rho0*c[1];vals.append([c[0],1/K,c[2]/K,c[2]])
 vals=np.array(vals);r['diagnostic_block_bootstrap_95_percentiles']={k:np.quantile(vals[:,i],[.025,.975]).tolist() for i,k in enumerate(['pressure_bar','kappa_bar_inverse','alpha_K_inverse','P_T_bar_K'])};r['uncertainty_caveat']='Four 5ps blocks per state; diagnostic bootstrap may underestimate slow correlation. No score replacement or confidence-qualified feasibility.';p.write_text(json.dumps(r,indent=2));rows.append(r)
rows.sort(key=lambda a:a['completed_utc'])
for i,r in enumerate(rows):r['sequence']=i
(D/'TRIALS.json').write_text(json.dumps(rows,indent=2))
print('Merged',len(rows),'records; best',min(rows,key=lambda a:a['objective_value'])['trial_id'])
