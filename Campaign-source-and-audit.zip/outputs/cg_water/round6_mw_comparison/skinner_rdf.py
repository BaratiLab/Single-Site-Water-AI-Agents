"""Exact radial-shell average of piecewise-linear primary experimental gOO."""
from pathlib import Path
import numpy as np
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'round6_reference'))
import reference as primary_reference
B=Path(__file__).resolve().parent.parent
REF=B/'round6_reference/Skinner2013_gOO_295p15K.npz'
def shell_average(x,y,lo,hi):
 out=[]
 for a,b in zip(lo,hi):
  z=np.r_[a,x[(x>a)&(x<b)],b];v=np.interp(z,x,y);m=np.diff(v)/np.diff(z);c=v[:-1]-m*z[:-1];integ=np.sum(m/4*np.diff(z**4)+c/3*np.diff(z**3));out.append(integ/((b**3-a**3)/3))
 return np.array(out)
def compare(r,g,blockg=None):
 q=np.load(REF);assert abs(float(q['temperature_K'])-295.15)<1e-6;dr=np.median(np.diff(r));assert abs(dr-.05)<1e-8;edges=np.arange(0,6.00001,.05);assert np.allclose(r,(edges[1:]+edges[:-1])/2);target=primary_reference.shell_average(edges);point=np.interp(r,q['r_A'],q['g']);err=primary_reference.shell_average(edges,field='estimated_error');shared=primary_reference.compare(r,g,edges);out={'experimental_T_K':295.15,'bin_width_A':float(dr),'reference_estimator':'Exactr²weightedradialshellaverageofpiecewise-linear0.01Aauthorcurve','estimated_error_scope':'Author-providedestimatederrorsretained,notindependentGaussians;nochi-square/significanceclaim'}
 for stop in [3.4,5.8]:
  mask=(r>=2.4)&(r<=stop);key=f'RMSE_Skinner_2p4_{stop:g}_shellaveraged';out[key]=float(np.sqrt(np.mean((g[mask]-target[mask])**2)));out[key+'_point_interpolation_sensitivity']=float(np.sqrt(np.mean((g[mask]-point[mask])**2)))
  if blockg is not None:
   b=np.array(blockg);delete=np.array([(b.sum(0)-v)/(len(b)-1) for v in b]);v=np.array([np.sqrt(np.mean((d[mask]-target[mask])**2)) for d in delete]);out[key+'_delete_block_jackknife_SE_descriptive']=float(np.sqrt((len(b)-1)/len(b)*np.sum((v-v.mean())**2)))
 out.update(shared);out['preliminary_fullcurve_gate_threshold']=.15;out['preliminary_fullcurve_point_gate_pass']=bool(out['RMSE_Skinner_2p4_5.8_shellaveraged']<=.15);return out,target,point,err

def rdf_blocks(frames,boxes,blocks=8):
 edges=np.arange(0,6.00001,.05);gs=[]
 for x,L in zip(frames,boxes):
  n=len(x);d=x[None,:,:]-x[:,None,:];d-=L*np.rint(d/L);rr=np.linalg.norm(d,axis=2);gs.append(np.histogram(rr[np.triu_indices(n,1)],edges)[0]/(n*(n-1)/2*(4*np.pi/3*np.diff(edges**3))/np.prod(L)))
 b=np.array([v.mean(0) for v in np.array_split(np.array(gs),blocks)]);return (edges[1:]+edges[:-1])/2,np.mean(gs,axis=0),b
