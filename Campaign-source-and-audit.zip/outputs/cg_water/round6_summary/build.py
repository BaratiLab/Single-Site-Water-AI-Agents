from pathlib import Path
import json,hashlib,argparse,shutil
D=Path(__file__).resolve().parent;B=D.parent
p=argparse.ArgumentParser();p.add_argument('--candidate',type=Path,required=True);p.add_argument('--sha',required=True);p.add_argument('--trial',required=True);args=p.parse_args()
def read(rel):return json.loads((B/rel).read_text())
assert hashlib.sha256(args.candidate.read_bytes()).hexdigest()==args.sha
m=json.loads(args.candidate.read_text());trials=read('round6_fit/TRIALS.json')
source=next(x for x in trials if x['trial_id']==args.trial and x['stage'].startswith('N512'))
large=[x for x in trials if x['stage'].startswith('N512')]
amendment=read('round6_summary/SELECTION_AMENDMENT.json')
assert amendment['primary_candidate']=='c34' and args.trial=='r6_N512_c34'
original=json.loads(Path(source['model_path']).read_text())
for key in ['pair_knots_A','pair_coefficients_descending','lambda_kJ_mol','angular_cutoff_A','embedding','undercoordination','angular_coordination','angular_polynomial','angular_weight','mass_amu']:
 assert m.get(key)==original.get(key),('Frozen physics differs',key)
comp=read('round6_validation/COMPARISON.json');gates=read('round6_validation/GATES.json')
assert comp['models']['new_candidate']['model_SHA256']==args.sha
response=read('round6_validation/RESPONSE_QUALIFICATION.json')
fast_path=B/'round6_optimization/FAST_BENCHMARK.json'
fast=json.loads(fast_path.read_text()) if fast_path.exists() else None
bench=read('round6_benchmark/RESULTS.json')
assert bench['candidate_sha256']==args.sha
if fast is not None:assert fast['candidate_sha256']==args.sha
result={'model':str(args.candidate.resolve()),'model_SHA256':args.sha,'source_trial_id':args.trial,'source_model_SHA256':source['model_sha256'],'selected_training_worst_normalized_violation':source['objective_value'],'selection_amendment':amendment,'training_record_count':len(trials),'screen_record_count':sum(x['stage'].startswith('N64') for x in trials),'large_cell_refinement_count':len(large),'independent_comparison':comp,'independent_gates':gates,'response_qualification':response,'runtime_benchmark':bench,'exact_kernel_optimization_benchmark':fast,'LLMSR':read('round6_llmsr/native_final/manifest.json'),'qualification':'Held-out results do not retune this frozen model. Mean research gates are not experimental-accuracy certification. No universal-water or equal-accuracy speedup claim.'}
(D/'RESULTS.json').write_text(json.dumps(result,indent=2))
shutil.copyfile(B/'round6_validation/PROPERTY_COMPARISON.csv',D/'PROPERTY_COMPARISON.csv')
lines=['ROUND 6: JOINT SINGLE-BEAD WATER-MODEL FIT AND VALIDATION','',f'Frozen candidate: {args.candidate.resolve()}',f'SHA256: {args.sha}',f'Training: {result["screen_record_count"]} small-cell EOS screens; {len(large)} same-budget larger-cell refinements. Additional pressure probes/diagnostics and excluded wrong-lookup runs are recorded separately.',f'Training selection: c34 primary (score {source["objective_value"]:.6g}) under the explicit pre-holdout density-risk amendment; c33 remains the original strict-minimax winner. See SELECTION_AMENDMENT.json.','Selection, implementation and independent validation are separate stages. No held-out results are used to alter this candidate.','',f'Independent mean research gates pass: {gates["all_mean_research_gates_pass"]}',f'Failed mean gates: {", ".join(gates["failed_mean_research_gates"]) or "none"}', f'Overall response qualification: {response["overall_status"]}.', 'Expansion/thermal-pressure intervals include zero. Direct central-state pressure is 182.65 bar (T-corrected 180.17 bar), versus the global-plane intercept of 66.45 bar. No transport progression is justified.', 'These broad research tolerances are not experimental-level accuracy or production qualification. See confidence intervals, estimator sensitivity and phase diagnostics in round6_validation/REPORT.md.','','PROPERTY COMPARISON:']
def fmt(x):return 'not computed' if x is None else f'{x:.8g}' if isinstance(x,(float,int)) else str(x)
for r in comp['rows']:
 lines.append(f'{r["property"]} [{r["unit"]}]: previous={fmt(r["previous_round5"])}, native mW={fmt(r["native_mW"])}, new={fmt(r["new_candidate"])}, reference={fmt(r["reference"])}. {r["qualification"]}')
lines+=['','COST:',json.dumps(bench['summary'],indent=2),bench['scope'],'','WHAT CHANGED:', 'Joint radial-shell updates, independent positive angular strength, stabilized coordination terms, sparse undercoordination corrections and broader second-shell density descriptors were tested. Original numerical experimental gOO at295.15K replaces OPC3 as the primary structural reference. Native mW was simulated under matching protocols.', 'The actual upstream LLM-SR buffer was updated repeatedly between adaptive batches. Its agent-authored file sampler is a bounded, transparent workflow; numerical fitting and MD are external. No exhaustive optimum or external API search is claimed.', '', 'FAILED HYPOTHESES:', 'Born/fluctuation ranking failed its EOS check and was replaced. Large radial-coordinate warps caused severe pressure/structure failures; those models remain recorded. Early static counterterms often failed after relaxation. Incorrect-lookup repeated-parent runs are preserved but excluded from intended-family selection.', '', 'REMAINING GAPS:', 'A cohesion proxy is not coexistence vaporization enthalpy. Raw CG heat capacities omit molecular degrees of freedom. No intrinsic dipole/dielectric relaxation exists in this neutral position-only Hamiltonian. New-model diffusion, viscosity, surface tension, TMD, melting, boiling/vapor pressure and thermal conductivity require their own validation; old results do not transfer.', 'Transport calibration is conditional on acceptable equilibrium sampling and must fit diffusion/viscosity together. A thermostat cannot fix an equilibrium EOS error.', '', 'See SYMBOLIC_MODEL.txt, round6_engine/REPRODUCE.txt, METHOD_LIMITS.txt and the compact source/audit bundle. Raw MD trajectories remain in the workspace.']
if fast is not None:
 lines+=['','SEPARATE EXACT-KERNEL COST EXPERIMENT:',json.dumps(fast.get('summary',fast),indent=2),fast.get('scope','See FAST_BENCHMARK.json for protocol and limitations')]
(D/'REPORT.txt').write_text('\n'.join(lines)+'\n')
(D/'STATUS.json').write_text(json.dumps({'stages':'Implementation, joint fitting, native mW comparison, fresh held-out EOS/NPT/RDF and controlled runtime comparison completed.','model_SHA256':args.sha,'all_mean_research_gates_pass':gates['all_mean_research_gates_pass'],'failed_mean_research_gates':gates['failed_mean_research_gates'],'overall_response_status':response['overall_status'],'automatic_transport_progression':False,'certified_universal_water_model':False},indent=2))
print(json.dumps({'model_SHA256':args.sha,'gates':gates['all_mean_research_gates_pass'],'failed':gates['failed_mean_research_gates'],'training_records':len(trials)}))
