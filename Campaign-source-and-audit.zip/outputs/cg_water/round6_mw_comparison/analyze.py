from pathlib import Path
import json, numpy as np
D=Path(__file__).resolve().parent
RHO=.99705;T0=298.15

def blockstats(x,n=8):
 b=np.array([np.mean(q) for q in np.array_split(x,n)])
 return dict(mean=float(np.mean(x)),SE=float(b.std(ddof=1)/np.sqrt(n)),blocks=b.tolist(),first_half=float(np.mean(x[:len(x)//2])),second_half=float(np.mean(x[len(x)//2:])))

def eos(states,boot=4000):
 X=np.array([[1,r['rho']-RHO,r['temperature']['mean']-T0] for r in states]);p=np.array([r['pressure']['mean'] for r in states]);c=np.linalg.lstsq(X,p,rcond=None)[0];rng=np.random.default_rng(909331);co=[]
 for _ in range(boot):
  idx=[rng.integers(0,len(r['pressure']['blocks']),len(r['pressure']['blocks'])) for r in states];pp=[np.mean(np.array(r['pressure']['blocks'])[ii]) for r,ii in zip(states,idx)];XX=np.array([[1,r['rho']-RHO,np.mean(np.array(r['temperature']['blocks'])[ii])-T0] for r,ii in zip(states,idx)]);co.append(np.linalg.lstsq(XX,pp,rcond=None)[0])
 co=np.array(co);kk=1/(RHO*co[:,1]);aa=co[:,2]/(RHO*co[:,1]);root=RHO+(1-c[0])/c[1]
 targetX=np.array([[1,r['rho']-RHO,r['target_T']-T0] for r in states]);targetc=np.linalg.lstsq(targetX,p,rcond=None)[0]
 return {'target_temperature_sensitivity':{'kappa_bar_inverse':float(1/(RHO*targetc[1])),'alpha_K_inverse':float(targetc[2]/(RHO*targetc[1]))},'intercept_bar':float(c[0]),'dP_drho_bar_per_g_cm3':float(c[1]),'dP_dT_bar_per_K':float(c[2]),'kappa_bar_inverse':float(1/(RHO*c[1])),'alpha_K_inverse':float(c[2]/(RHO*c[1])),'rho_root_1bar':float(root),'root_bracketed':bool(.98<=root<=1.015),'positive_slope_bootstrap_fraction':float(np.mean(co[:,1]>0)),'bootstrap95_kappa':np.percentile(kk,[2.5,97.5]).tolist(),'bootstrap95_alpha':np.percentile(aa,[2.5,97.5]).tolist(),'max_half_pressure_difference_bar':max(abs(r['pressure']['first_half']-r['pressure']['second_half']) for r in states),'qualification':'Short local derivative pilot; block bootstrap intervals descriptive, equilibrium and finite-size independence unestablished.'}

def structure(frames,boxes):
 edges=np.arange(0,6.00001,.05);gs=[];qs=[];cs=[]
 for x,L in zip(frames,boxes):
  L=np.array(L);d=x[None,:,:]-x[:,None,:];d-=L*np.rint(d/L);rr=np.linalg.norm(d,axis=2);n=len(x);h=np.histogram(rr[np.triu_indices(n,1)],edges)[0];gs.append(h/(n*(n-1)/2*(4*np.pi/3*np.diff(edges**3))/np.prod(np.broadcast_to(L,(3,)))));cs.append(np.sum((rr>0)&(rr<3.4))/n);np.fill_diagonal(rr,np.inf);nn=np.argsort(rr,axis=1)[:,:4];u=d[np.arange(n)[:,None],nn];u/=np.linalg.norm(u,axis=2)[:,:,None];co=np.einsum('nia,nja->nij',u,u);ii,jj=np.triu_indices(4,1);qs.append(np.mean(1-3/8*np.sum((co[:,ii,jj]+1/3)**2,axis=1)))
 r=.5*(edges[:-1]+edges[1:]);g=np.mean(gs,axis=0);ref=np.load(D.parents[1]/'v7/round7_rdf/rdf_1_OO.npz');target=np.interp(r,ref['r_A'],ref['g']);pk=np.flatnonzero((r>=2.4)&(r<=3.2));i=pk[np.argmax(g[pk])];out={'first_peak_A':float(r[i]),'first_peak_height':float(g[i]),'coordination_3p4':float(np.mean(cs)),'tetrahedral_q':float(np.mean(qs)),'frames':len(frames)}
 for stop in [3.4,5.8]:
  sel=(r>=2.4)&(r<=stop);out[f'RDF_RMSE_2p4_{stop:g}']=float(np.sqrt(np.mean((g[sel]-target[sel])**2)))
 return out,r,g

def read_dump(path,minstep=0):
 xx=[];boxes=[]
 with Path(path).open() as f:
  while f.readline():
   step=int(f.readline());f.readline();n=int(f.readline());f.readline();lim=np.array([[float(v) for v in f.readline().split()[:2]] for _ in range(3)]);f.readline();x=np.array([[float(v) for v in f.readline().split()[2:5]] for _ in range(n)])
   if step>minstep:xx.append(x);boxes.append(lim[:,1]-lim[:,0])
 return np.array(xx),np.array(boxes)
